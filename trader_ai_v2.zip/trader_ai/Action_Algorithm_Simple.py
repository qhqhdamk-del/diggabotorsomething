

from datetime import datetime, timedelta, timezone
from typing import List, Literal, Optional

from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit

Signal = Literal["BUY", "SELL", "HOLD"]

_TIMEFRAME_MAP = {
    "1m": TimeFrame(1, TimeFrameUnit.Minute),
    "5m": TimeFrame(5, TimeFrameUnit.Minute),
    "15m": TimeFrame(15, TimeFrameUnit.Minute),
    "30m": TimeFrame(30, TimeFrameUnit.Minute),
    "1h": TimeFrame(1, TimeFrameUnit.Hour),
    "1d": TimeFrame(1, TimeFrameUnit.Day),
}


class TradingAlgo:
    
    _shared_client: Optional[StockHistoricalDataClient] = None

    def __init__(
        self,
        ticker: str,
        short_window: int = 9,
        long_window: int = 21,
        rsi_period: int = 14,
        rsi_overbought: float = 70.0,
        rsi_oversold: float = 30.0,
        interval: str = "5m",
        lookback_days: int = 5,
        api_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        client: Optional[StockHistoricalDataClient] = None,
    ):
        self.ticker = ticker.upper()
        self.short_window = short_window
        self.long_window = long_window
        self.rsi_period = rsi_period
        self.rsi_overbought = rsi_overbought
        self.rsi_oversold = rsi_oversold
        self.interval = interval
        self.lookback_days = lookback_days

        if interval not in _TIMEFRAME_MAP:
            raise ValueError(
                f"Invalid interval {interval!r}. "
                f"Choose from: {list(_TIMEFRAME_MAP)}"
            )
        self._timeframe = _TIMEFRAME_MAP[interval]

        
        if client is not None:
            self.client = client
        elif TradingAlgo._shared_client is not None:
            self.client = TradingAlgo._shared_client
        else:
            key = api_key or "ADD_KEY_HERE"
            secret = secret_key or "ADD_KEY_HERE"
            if not key or not secret:
                raise ValueError(
                    "Alpaca credentials missing. Set ALPACA_API_KEY and "
                    "ALPACA_SECRET_KEY env vars, or pass api_key=/secret_key=."
                )
            self.client = StockHistoricalDataClient(key, secret)
            TradingAlgo._shared_client = self.client

    

    def fetch_prices(self) -> List[float]:
        
        start = datetime.now(timezone.utc) - timedelta(days=self.lookback_days)
        request = StockBarsRequest(
            symbol_or_symbols=self.ticker,
            timeframe=self._timeframe,
            start=start,
        )
        bars = self.client.get_stock_bars(request)
        if self.ticker not in bars.data or not bars.data[self.ticker]:
            raise RuntimeError(f"No data returned for {self.ticker}")
        return [bar.close for bar in bars.data[self.ticker]]

    

    @staticmethod
    def _sma(prices: List[float], window: int) -> float:
        if len(prices) < window:
            raise ValueError(f"Need at least {window} prices, got {len(prices)}")
        return sum(prices[-window:]) / window

    def _rsi(self, prices: List[float]) -> float:
        if len(prices) < self.rsi_period + 1:
            raise ValueError(
                f"Need at least {self.rsi_period + 1} prices for RSI"
            )
        gains, losses = [], []
        for i in range(-self.rsi_period, 0):
            change = prices[i] - prices[i - 1]
            gains.append(max(change, 0))
            losses.append(abs(min(change, 0)))
        avg_gain = sum(gains) / self.rsi_period
        avg_loss = sum(losses) / self.rsi_period
        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    

    def get_signal(self, prices: Optional[List[float]] = None) -> Signal:
        
        if prices is None:
            prices = self.fetch_prices()

        short_ma = self._sma(prices, self.short_window)
        long_ma = self._sma(prices, self.long_window)
        rsi = self._rsi(prices)

        if short_ma > long_ma and rsi < self.rsi_overbought:
            return "BUY"
        if short_ma < long_ma or rsi > self.rsi_overbought:
            return "SELL"
        return "HOLD"

    def analyze(self, prices: Optional[List[float]] = None) -> dict:
        
        if prices is None:
            prices = self.fetch_prices()
        return {
            "ticker": self.ticker,
            "signal": self.get_signal(prices),
            "short_ma": self._sma(prices, self.short_window),
            "long_ma": self._sma(prices, self.long_window),
            "rsi": self._rsi(prices),
            "current_price": prices[-1],
            "num_bars": len(prices),
        }
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Optional
import math

import numpy as np
import pandas as pd

from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit


MIN_BARS_REQUIRED = 65


_SHORT_MA  = 20
_LONG_MA   = 50
_RSI_PERIOD = 14



_ATR_PERIOD = 14
_ATR_STOP   = 2.0   
_ATR_TP     = 3.0   


_api_key:    str = ""
_secret_key: str = ""
_feed:       str = "sip"


def configure(
    api_key:    str = "",
    secret_key: str = "",
    feed:       str = "sip",
) -> None:
    global _api_key, _secret_key, _feed
    _api_key    = api_key
    _secret_key = secret_key
    _feed       = feed


def _fetch_bars(
    symbol:      str,
    bar_minutes: int,
    days:        int,
    feed:        Optional[str] = None,
) -> pd.DataFrame:
    if not _api_key:
        raise RuntimeError(
            "Credentials not set. Call daytrader.configure(api_key, secret_key) first."
        )

    client = StockHistoricalDataClient(
        api_key=_api_key,
        secret_key=_secret_key,
    )

    
    tf = TimeFrame(bar_minutes, TimeFrameUnit.Minute)

    end   = datetime.now(tz=timezone.utc)
    start = end - timedelta(days=days)

    request = StockBarsRequest(
        symbol_or_symbols=symbol,
        timeframe=tf,
        start=start,
        end=end,
        feed=feed or _feed,
    )

    bars = client.get_stock_bars(request)
    df   = bars.df

    
    if isinstance(df.index, pd.MultiIndex):
        df = df.xs(symbol, level="symbol")

    df.index.name = "timestamp"
    df = df[["open", "high", "low", "close", "volume"]].copy()
    df = df.sort_index()
    return df



def _compute_rsi(close: pd.Series, period: int = 14) -> float:

    delta  = close.diff().dropna()
    gain   = delta.clip(lower=0)
    loss   = (-delta).clip(lower=0)
    avg_g  = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_l  = loss.ewm(com=period - 1, min_periods=period).mean()
    rs     = avg_g / avg_l.replace(0, np.nan)
    rsi    = 100 - (100 / (1 + rs))
    return float(rsi.iloc[-1])


def _compute_atr(window: pd.DataFrame, period: int = 14) -> float:
    high       = window["high"]
    low        = window["low"]
    close      = window["close"]
    prev_close = close.shift(1)

    tr = pd.concat(
        [high - low,
         (high - prev_close).abs(),
         (low  - prev_close).abs()],
        axis=1,
    ).max(axis=1)

    atr = tr.ewm(com=period - 1, min_periods=period).mean()
    return float(atr.iloc[-1])



def _decide(
    symbol:         str,
    window:         pd.DataFrame,
    cash:           float,
    prior_position: Optional[str],
) -> dict:
    close = window["close"]

    
    if len(close) < _LONG_MA + _RSI_PERIOD:
        return {
            "action": "CONTINUE", "signal": prior_position or "BUY",
            "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
        }

    short_ma = float(close.tail(_SHORT_MA).mean())
    long_ma  = float(close.tail(_LONG_MA).mean())
    rsi      = _compute_rsi(close, _RSI_PERIOD)
    atr      = _compute_atr(window, _ATR_PERIOD)
    price    = float(close.iloc[-1])

    
    if short_ma > long_ma and rsi < 70:
        raw_signal = "BUY"
    elif short_ma < long_ma and rsi > 30:
        raw_signal = "SELL"
    else:
        raw_signal = "HOLD"

    
    if prior_position is None:
        
        if raw_signal in ("BUY", "SELL"):
            shares = math.floor(cash / price) if price > 0 else 0
            if raw_signal == "BUY":
                stop_price  = price - _ATR_STOP * atr
                take_profit = price + _ATR_TP   * atr
            else:
                stop_price  = price + _ATR_STOP * atr
                take_profit = price - _ATR_TP   * atr
            return {
                "action":      "ENTER",
                "signal":      raw_signal,
                "shares":      shares,
                "stop_loss":   round(stop_price,  4),
                "take_profit": round(take_profit, 4),
            }
        
        return {
            "action": "CONTINUE", "signal": "BUY",
            "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
        }

    else:
        
        if raw_signal == "HOLD" or raw_signal == prior_position:
            
            return {
                "action": "CONTINUE", "signal": prior_position,
                "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
            }
        else:
            
            return {
                "action": "EXIT", "signal": prior_position,
                "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
            }

import os
import sys
import time
import math
import threading
from datetime import datetime


from Stock_Watchlist_Gemini import get_watchlist                
from Action_Algorithm_Simple import TradingAlgo                 
from Action_Algorithm_Complex import analyze as complex_analyze  
import trade_backtester                                          


from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, TakeProfitRequest, StopLossRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderClass



API_KEY_FILE = "API_KEY.txt"

LIVE_TRADING = False


SCAN_INTERVAL = 15


WATCHLIST_REFRESH_INTERVAL = 3600

_watchlist: list[dict] = []
_watchlist_lock = threading.Lock()

_last_signals: dict[str, dict] = {}
_signals_lock = threading.Lock()


_last_executed_signal: dict[str, str] = {}
_executed_lock = threading.Lock()


_shutdown = threading.Event()


def load_api_keys() -> tuple[str, str]:

    script_dir    = os.path.dirname(os.path.abspath(__file__))
    key_file_path = os.path.join(script_dir, API_KEY_FILE)

    if os.path.exists(key_file_path):
        print(f"[INFO] Found {API_KEY_FILE} — loading API keys from file.")
        try:
            with open(key_file_path, "r") as f:
                lines = [line.strip() for line in f if line.strip()]
            if len(lines) < 2:
                print(f"[ERROR] {API_KEY_FILE} must have two lines: API Key ID then Secret Key.")
                raise SystemExit(1)
            api_key, secret_key = lines[0], lines[1]
            if not (api_key.startswith("PK") or api_key.startswith("AK")):
                print("[WARNING] API key doesn't start with 'PK'/'AK' — double-check it.")
            print("[INFO] API keys loaded.")
            return api_key, secret_key
        except OSError as e:
            print(f"[ERROR] Could not read {API_KEY_FILE}: {e}")
            raise SystemExit(1)

    else:
        print(f"[INFO] {API_KEY_FILE} not found — please enter your Alpaca API keys.")
        print("       They will be saved automatically so you won't be asked again.\n")

        while True:
            api_key = input("  Enter your API Key ID : ").strip()
            if api_key:
                break
            print("  [ERROR] API Key ID cannot be empty.")

        while True:
            secret_key = input("  Enter your Secret Key : ").strip()
            if secret_key:
                break
            print("  [ERROR] Secret Key cannot be empty.")

        try:
            with open(key_file_path, "w") as f:
                f.write(f"{api_key}\n{secret_key}\n")
            print(f"\n[INFO] Keys saved to {key_file_path}")
            print("[INFO] Keep this file private and out of version control.\n")
        except OSError as e:
            print(f"[WARNING] Could not save keys: {e}")

        return api_key, secret_key


def create_client(api_key: str, secret_key: str) -> TradingClient:
    paper_mode = not LIVE_TRADING
    mode_label = "LIVE" if LIVE_TRADING else "PAPER"
    print(f"[INFO] Connecting to Alpaca ({mode_label} mode)...")
    return TradingClient(api_key=api_key, secret_key=secret_key, paper=paper_mode)


def get_position_qty(client: TradingClient, symbol: str) -> float:

    try:
        position = client.get_open_position(symbol)
        return float(position.qty)
    except Exception:
        
        return 0.0


def get_current_price(complex_result: dict) -> float:
    return float(complex_result.get("entry_price", 0.0))


def liquidate_all_positions(client: TradingClient) -> None:

    try:
        positions = client.get_all_positions()
    except Exception as e:
        print(f"[LIQUIDATE] Could not fetch positions: {e}")
        return

    if not positions:
        print("[LIQUIDATE] No open positions to close.")
        return

    symbols = [p.symbol for p in positions]
    print(f"[LIQUIDATE] Closing {len(positions)} position(s): {symbols}")

    try:
        
        client.close_all_positions(cancel_orders=True)
    except Exception as e:
        print(f"[LIQUIDATE] close_all_positions failed: {e}")
        return

    
    for elapsed in range(0, 61, 3):
        time.sleep(3)
        try:
            remaining = client.get_all_positions()
        except Exception:
            remaining = []
        if not remaining:
            print(f"[LIQUIDATE] All positions closed after {elapsed + 3}s.")

            
            with _executed_lock:
                _last_executed_signal.clear()
            return
        print(f"[LIQUIDATE] Waiting for {len(remaining)} position(s) to settle... ({elapsed + 3}s)")

    print("[LIQUIDATE] WARNING: Some positions may still be open after 60s. "
          "Check your Alpaca dashboard.")



def place_order(
    client: TradingClient,
    symbol: str,
    qty: float,
    side: OrderSide,
    price_mode: str,
    entry_price: float = 0.0,
    stop_loss: float   = 0.0,
    take_profit: float = 0.0,
    regime: str        = "unknown",
    adx_value: float   = 0.0,
) -> None:

    qty = math.floor(qty)
    if qty == 0:
        print(f"  {symbol:<6}  SKIP    Rounded qty=0 — budget too small for one share.")
        return False

    try:
        if price_mode == "ai" and entry_price > 0 and stop_loss > 0 and take_profit > 0:
            is_trending = regime in ("trending_up", "trending_down")
            is_strong   = adx_value >= 25 and is_trending

            stop_dist = abs(entry_price - stop_loss)
            tp_dist   = abs(entry_price - take_profit)

            if not is_strong:
                stop_dist *= 1.20
                tp_dist   *= 0.80
                adj_label  = f"adj(ADX={adx_value:.1f},{regime})"
            else:
                adj_label  = f"raw(ADX={adx_value:.1f},{regime})"

            if side == OrderSide.BUY:
                adj_stop = entry_price - stop_dist
                adj_tp   = entry_price + tp_dist
            else:
                adj_stop = entry_price + stop_dist
                adj_tp   = entry_price - tp_dist

            request = LimitOrderRequest(
                symbol=symbol,
                qty=qty,
                side=side,
                limit_price=round(entry_price, 2),
                time_in_force=TimeInForce.DAY,
                order_class=OrderClass.BRACKET,
                take_profit=TakeProfitRequest(limit_price=round(adj_tp,   2)),
                stop_loss=StopLossRequest(stop_price=round(adj_stop, 2)),
            )
            order = client.submit_order(request)
            print(f"  {symbol:<6}  ORDER   {side.value.upper()} {qty} shares  "
                  f"entry=${entry_price:.2f}  sl=${adj_stop:.2f}  tp=${adj_tp:.2f}  "
                  f"{adj_label}  id={str(order.id)[:8]}")

        else:
            request = MarketOrderRequest(
                symbol=symbol,
                qty=qty,
                side=side,
                time_in_force=TimeInForce.DAY,
            )
            order = client.submit_order(request)
            print(f"  {symbol:<6}  ORDER   {side.value.upper()} {qty} shares  "
                  f"market price  id={str(order.id)[:8]}")

        return True   

    except Exception as e:
        print(f"  {symbol:<6}  ERROR   Order failed: {e}")
        return False  



def decide_and_trade(
    client: TradingClient,
    stock: dict,
    amount_per_trade: float,
    price_mode: str,
    use_simple: bool,
) -> None:

    symbol = stock["symbol"]
    risk   = stock["risk"].upper()   

    
    
    
    simple_signal = None   

    if use_simple:
        try:
            simple_result = TradingAlgo(symbol).analyze()
            simple_signal = simple_result["signal"].upper()    
        except Exception as e:
            print(f"  {symbol:<6}  ERROR   Simple algo failed: {e}")
            return

    try:
        complex_result   = complex_analyze(symbol, feed="iex")
        complex_signal   = complex_result["signal"].upper()  
        algo_entry       = float(complex_result.get("entry_price", 0.0))
        algo_stop_loss   = float(complex_result.get("stop_loss",   0.0))
        algo_take_profit = float(complex_result.get("take_profit", 0.0))

        
        reasoning     = complex_result.get("reasoning", {})
        regime        = reasoning.get("regime",          "unknown")  
        adx_value     = float(reasoning.get("adx_value",       0.0))  
        slope_pct     = float(reasoning.get("slope_pct_10bar", 0.0))  
        above_50ema   = int(reasoning.get("above_50ema",         0))  
        veto          = reasoning.get("veto",               None)    
    except Exception as e:
        print(f"  {symbol:<6}  ERROR   Complex algo failed: {e}")
        return

    price = get_current_price(complex_result)

    
    with _signals_lock:
        _last_signals[symbol] = {
            "simple":     simple_signal,
            "complex":    complex_signal,
            "price":      price,
            "confidence": complex_result.get("confidence", 0),
            "regime":     regime,
            "adx":        adx_value,
            "slope_pct":  slope_pct,
            "above_50ema":above_50ema,
            "veto":       veto,
        }

    
    
    if veto is not None:
        print(f"  {symbol:<6}  HOLD    VETOED: {veto}  "
              f"(regime={regime}, ADX={adx_value:.1f})")
        return

    current_qty  = get_position_qty(client, symbol)
    has_position = (current_qty != 0.0)


    final_signal: str | None = None

    if not use_simple:
        
        if complex_signal in ("BUY", "SELL"):
            final_signal = complex_signal
    elif not has_position:
        if risk == "LOW":
            if complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal
        else:
            if simple_signal == complex_signal and complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal
    else:
        if risk == "LOW":
            if simple_signal == complex_signal and complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal
        else:
            if complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal

    if final_signal is None:
        final_signal = "HOLD"

    
    
    
    regime_block = (
        (final_signal == "BUY"  and regime == "trending_down") or
        (final_signal == "SELL" and regime == "trending_up")
    )
    ema_block = (
        (final_signal == "BUY"  and above_50ema == -1) or
        (final_signal == "SELL" and above_50ema == +1)
    )

    if regime_block:
        print(f"  {symbol:<6}  HOLD    regime conflict: {final_signal} vs {regime}  "
              f"ADX={adx_value:.1f}  slope={slope_pct:+.2f}%")
        return

    if ema_block:
        print(f"  {symbol:<6}  HOLD    50EMA conflict: {final_signal} vs "
              f"above_50ema={above_50ema:+d}  regime={regime}")
        return


    
    with _executed_lock:
        prev_signal = _last_executed_signal.get(symbol)

    if final_signal == "HOLD" or final_signal == prev_signal:
        reason      = "no change" if final_signal == prev_signal else "algo says hold"
        simple_part = f"simple={simple_signal:<4}  " if use_simple else ""
        print(f"  {symbol:<6}  HOLD    "
              f"{simple_part}complex={complex_signal:<4}  "
              f"regime={regime:<12}  ADX={adx_value:>5.1f}  "
              f"pos={current_qty:>+6.0f}  price=${price:>8.2f}  ({reason})")
        return

    
    if price <= 0:
        print(f"  {symbol:<6}  SKIP    Could not determine price.")
        return

    trade_shares = math.floor(amount_per_trade / price)

    if trade_shares <= 0:
        print(f"  {symbol:<6}  SKIP    Budget too small for 1 share at ${price:.2f}.")
        return

    
    
    target_qty = trade_shares if final_signal == "BUY" else -trade_shares
    order_qty  = target_qty - current_qty

    if order_qty == 0:
        print(f"  {symbol:<6}  HOLD    Already at target position ({current_qty:+.0f}).")
        return

    order_side = OrderSide.BUY if order_qty > 0 else OrderSide.SELL

    simple_part = f"simple={simple_signal:<4}  " if use_simple else ""
    print(f"  {symbol:<6}  {final_signal:<6}  "
          f"{simple_part}complex={complex_signal:<4}  "
          f"regime={regime:<12}  ADX={adx_value:>5.1f}  ema={above_50ema:+d}  "
          f"pos={current_qty:>+6.0f}→{target_qty:>+6.0f}  "
          f"price=${price:>8.2f}  {order_side.value.upper()} {abs(order_qty):.0f} shares")

 
    order_placed = place_order(
        client, symbol, abs(order_qty), order_side,
        price_mode=price_mode,
        entry_price=algo_entry,
        stop_loss=algo_stop_loss,
        take_profit=algo_take_profit,
        regime=regime,
        adx_value=adx_value,
    )

    if order_placed:
        
        with _executed_lock:
            _last_executed_signal[symbol] = final_signal
        
        trade_backtester.run_after_trade(symbol, capital=amount_per_trade)


def _watchlist_refresh_loop(client: TradingClient) -> None:

    global _watchlist
    first_run = True
    while not _shutdown.is_set():
        
        
        if not first_run:
            print("\n[WATCHLIST] Watchlist refresh due — liquidating all positions first...")
            liquidate_all_positions(client)
        first_run = False

        print("\n[WATCHLIST] Fetching new watchlist from Gemini...")
        try:
            new_list = get_watchlist()
            with _watchlist_lock:
                _watchlist = new_list
            symbols = [s["symbol"] for s in new_list]
            print(f"[WATCHLIST] Active watchlist: {symbols}")
        except Exception as e:
            print(f"[WATCHLIST] Error fetching watchlist: {e}")

        
        _shutdown.wait(timeout=WATCHLIST_REFRESH_INTERVAL)


def _trading_scan_loop(client: TradingClient, amount_per_trade: float, price_mode: str, use_simple: bool) -> None:

    while not _shutdown.is_set():

        try:
            clock = client.get_clock()
            if not clock.is_open:
                next_open = clock.next_open.strftime("%Y-%m-%d %H:%M %Z")
                print(f"\n[SCAN] Market is closed. Next open: {next_open}  — holding.")
                
                
                seconds_until_open = max(
                    0,
                    (clock.next_open - clock.timestamp).total_seconds() + 60,
                )
                _shutdown.wait(timeout=seconds_until_open)
                continue
        except Exception as e:
            print(f"[SCAN] Could not fetch market clock: {e} — skipping cycle.")
            _shutdown.wait(timeout=SCAN_INTERVAL)
            continue

        with _watchlist_lock:
            current_watchlist = list(_watchlist)   

        if not current_watchlist:
            print("[SCAN] Watchlist is empty — waiting for watchlist thread...")
            _shutdown.wait(timeout=SCAN_INTERVAL)
            continue

        scan_time   = datetime.now().strftime("%H:%M:%S")
        mode_label  = "AI price" if price_mode == "ai" else "market price"
        algo_label  = "complex+simple" if use_simple else "complex only"
        print(f"\n[SCAN] {scan_time}  budget=${amount_per_trade:,.2f}/trade  "
              f"price={mode_label}  algo={algo_label}")
        print("  " + "─" * 62)

        for stock in current_watchlist:
            try:
                decide_and_trade(client, stock, amount_per_trade, price_mode, use_simple)
            except Exception as e:
                print(f"  {stock['symbol']:<6}  ERROR   Unexpected: {e}")

        print("  " + "─" * 62)

        
        _shutdown.wait(timeout=SCAN_INTERVAL)






def print_status(client: TradingClient) -> None:
    try:
        account   = client.get_account()
        positions = client.get_all_positions()

        print(f"\n{'═'*60}")
        print(f"  Account  |  Buying Power: ${float(account.buying_power):>12,.2f}"
              f"  |  Portfolio: ${float(account.portfolio_value):>12,.2f}")
        print(f"{'─'*60}")

        if positions:
            print(f"  {'SYMBOL':<6}  {'QTY':>8}  {'AVG ENTRY':>10}  "
                  f"{'MKT VALUE':>12}  {'UNREAL P/L':>12}")
            for p in positions:
                print(f"  {p.symbol:<6}  {float(p.qty):>+8.2f}  "
                      f"${float(p.avg_entry_price):>9,.4f}  "
                      f"${float(p.market_value):>11,.2f}  "
                      f"${float(p.unrealized_pl):>+11,.2f}")
        else:
            print("  (no open positions)")

        print(f"{'─'*60}")
        with _signals_lock:
            signals_snapshot = dict(_last_signals)

        if signals_snapshot:
            
            
            show_simple = any(sig.get("simple") is not None for sig in signals_snapshot.values())
            smpl_hdr    = f"{'SMPL':<4}  " if show_simple else ""
            print(f"  {'SYM':<6}  {smpl_hdr}{'CMPLX':<5}  {'CONF':>5}  "
                  f"{'REGIME':<12}  {'ADX':>5}  {'SLOPE':>6}  {'EMA':>3}  {'VETO'}")
            for sym, sig in signals_snapshot.items():
                veto_str  = sig.get("veto") or "—"
                smpl_part = f"{sig['simple']:<4}  " if show_simple else ""
                print(f"  {sym:<6}  {smpl_part}{sig['complex']:<5}  "
                      f"{sig['confidence']:>4.0%}  "
                      f"{sig.get('regime','?'):<12}  "
                      f"{sig.get('adx', 0):>5.1f}  "
                      f"{sig.get('slope_pct', 0):>+5.2f}%  "
                      f"{sig.get('above_50ema', 0):>+3d}  "
                      f"{veto_str}")

        print(f"{'═'*60}\n")

    except Exception as e:
        print(f"[STATUS] Could not retrieve account data: {e}")






def get_amount_per_trade() -> float:
    while True:
        raw = input("Enter amount per trade in USD (e.g. 500): $").strip()
        try:
            amount = float(raw)
            if amount > 0:
                return amount
            print("[ERROR] Amount must be greater than zero.")
        except ValueError:
            print("[ERROR] Please enter a valid number (e.g. 500 or 1000.50).")


def get_price_mode() -> str:

    print("\nPrice mode:")
    print("  [1] Market  — fill immediately at the current market price")
    print("  [2] AI      — TraderAI sets the entry price, stop-loss, and")
    print("                take-profit automatically using the complex algorithm")
    while True:
        choice = input("Choose (1 or 2): ").strip()
        if choice == "1":
            print("[INFO] Price mode: Market orders.")
            return "market"
        elif choice == "2":
            print("[INFO] Price mode: AI-decided limit + bracket orders.")
            return "ai"
        else:
            print("[ERROR] Please enter 1 or 2.")


def get_use_simple_algo() -> bool:

    print("\nSimple algorithm:")
    print("  [1] Enabled  — acts as a second opinion (cross-checks the complex algo)")
    print("  [2] Disabled — complex algorithm decides alone for all stocks")
    while True:
        choice = input("Choose (1 or 2): ").strip()
        if choice == "1":
            print("[INFO] Simple algorithm: ENABLED.")
            return True
        elif choice == "2":
            print("[INFO] Simple algorithm: DISABLED — complex algo decides alone.")
            return False
        else:
            print("[ERROR] Please enter 1 or 2.")

def main() -> None:
    print("=" * 60)
    print("  TraderAI — Automated Stock Trading Bot")
    mode = "LIVE (REAL MONEY)" if LIVE_TRADING else "PAPER (simulated)"
    print(f"  Mode: {mode}")
    print("=" * 60)

    
    if LIVE_TRADING:
        print("\n[WARNING] LIVE_TRADING is True — this uses REAL MONEY.")
        confirm = input("   Type 'yes' to continue, anything else to abort: ").strip().lower()
        if confirm != "yes":
            print("[INFO] Aborted.")
            return

    
    api_key, secret_key = load_api_keys()

    
    try:
        client = create_client(api_key, secret_key)
        acct = client.get_account()
        print(f"[INFO] Connected. Buying power: ${float(acct.buying_power):,.2f}\n")
    except Exception as e:
        print(f"[ERROR] Could not connect to Alpaca: {e}")
        return

    
    
    trade_backtester.configure(api_key=api_key, secret_key=secret_key, feed="sip")

    
    amount_per_trade = get_amount_per_trade()
    price_mode       = get_price_mode()
    use_simple       = get_use_simple_algo()
    print(f"\n[INFO] Budget: ${amount_per_trade:,.2f}/trade  |  "
          f"Price: {'AI limit orders' if price_mode == 'ai' else 'Market orders'}  |  "
          f"Algo: {'Complex + Simple' if use_simple else 'Complex only'}\n")

    
    
    
    watchlist_thread = threading.Thread(
        target=_watchlist_refresh_loop,
        args=(client,),
        name="WatchlistRefresh",
        daemon=True   
    )
    watchlist_thread.start()

    
    
    print("[INFO] Waiting for Gemini to return the initial watchlist "
          "(this can take up to a few minutes)...")
    wait_limit   = 180   
    wait_elapsed = 0
    while wait_elapsed < wait_limit:
        time.sleep(5)
        wait_elapsed += 5
        with _watchlist_lock:
            ready = bool(_watchlist)
        if ready:
            break
        print(f"[INFO] Still waiting for Gemini... ({wait_elapsed}s elapsed)")
    else:
        print("[WARNING] Gemini did not respond within 3 minutes. "
              "The scan thread will start anyway and retry on the next watchlist cycle.")

    
    scan_thread = threading.Thread(
        target=_trading_scan_loop,
        args=(client, amount_per_trade, price_mode, use_simple),
        name="TradingScan",
        daemon=True
    )
    scan_thread.start()

    
    print("[INFO] TraderAI is running. Press Ctrl+C to stop.\n")
    try:
        while True:
            time.sleep(30)          
            print_status(client)
    except KeyboardInterrupt:
        print("\n[INFO] Shutdown requested — liquidating all positions...")
        liquidate_all_positions(client)
        print("[INFO] Stopping all threads...")
        _shutdown.set()
        watchlist_thread.join(timeout=5)
        scan_thread.join(timeout=5)
        print("[INFO] TraderAI stopped. Goodbye.")
        sys.exit(0)


if __name__ == "__main__":
    main()
from __future__ import annotations
import threading

import daytrader
from backtester import backtest, BacktestResult


DEFAULT_DAYS        = 30   
DEFAULT_BAR_MINUTES = 5    

_MAX_CONCURRENT = 3
_semaphore = threading.Semaphore(_MAX_CONCURRENT)


def configure(api_key: str, secret_key: str, feed: str = "sip") -> None:

    daytrader.configure(api_key=api_key, secret_key=secret_key, feed=feed)


def run_after_trade(
    symbol:      str,
    capital:     float,
    days:        int = DEFAULT_DAYS,
    bar_minutes: int = DEFAULT_BAR_MINUTES,
) -> None:

    thread = threading.Thread(
        target=_backtest_worker,
        args=(symbol, capital, days, bar_minutes),
        name=f"Backtest-{symbol}",
        daemon=True,   
    )
    thread.start()
    print(f"  [BACKTEST] {symbol}  backtest queued "
          f"({days}d × {bar_minutes}m bars, capital=${capital:,.2f})")






def _backtest_worker(
    symbol:      str,
    capital:     float,
    days:        int,
    bar_minutes: int,
) -> None:

    
    with _semaphore:
        print(f"\n[BACKTEST] ── Starting: {symbol} "
              f"({days}d, {bar_minutes}m bars) ──────────────────────")
        try:
            result = backtest(
                symbol,
                days=days,
                bar_minutes=bar_minutes,
                capital=capital,
                feed="sip",
            )
            _print_result(result)
        except Exception as e:
            print(f"[BACKTEST] {symbol} failed: {e}")






def _print_result(r: BacktestResult) -> None:

    ret_sign = "+" if r.total_return_pct >= 0 else ""

    
    if r.profit_factor == float("inf"):
        pf_label = "∞ (no losses)"
    elif r.profit_factor >= 2.0:
        pf_label = f"{r.profit_factor:.2f}  ✓ strong"
    elif r.profit_factor >= 1.0:
        pf_label = f"{r.profit_factor:.2f}  ~ marginal"
    else:
        pf_label = f"{r.profit_factor:.2f}  ✗ unprofitable"

    
    if r.sharpe_approx >= 1.5:
        sharpe_label = f"{r.sharpe_approx:.2f}  ✓ good"
    elif r.sharpe_approx >= 0.5:
        sharpe_label = f"{r.sharpe_approx:.2f}  ~ acceptable"
    else:
        sharpe_label = f"{r.sharpe_approx:.2f}  ✗ poor"

    lines = [
        f"\n[BACKTEST] ┌── {r.symbol}  {r.start[:10]} → {r.end[:10]}  "
        f"({r.bar_minutes}m bars) ─────────────────",
        f"[BACKTEST] │  Capital:       ${r.starting_capital:>10,.2f}  →  "
        f"${r.ending_capital:>10,.2f}  ({ret_sign}{r.total_return_pct:.2f}%)",
        f"[BACKTEST] │  Trades:        {r.num_trades}  │  "
        f"Win rate: {r.win_rate:.1f}%",
        f"[BACKTEST] │  Avg win:       ${r.avg_win:>+9.2f}  │  "
        f"Avg loss: ${r.avg_loss:>+9.2f}",
        f"[BACKTEST] │  Profit factor: {pf_label}",
        f"[BACKTEST] │  Max drawdown:  {r.max_drawdown_pct:.2f}%",
        f"[BACKTEST] │  Sharpe:        {sharpe_label}",
        f"[BACKTEST] │  Total costs:   ${r.total_costs:.2f}",
        f"[BACKTEST] └─────────────────────────────────────────────────────\n",
    ]
    print("\n".join(lines))

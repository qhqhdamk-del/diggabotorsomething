from __future__ import annotations

import json
import os
import re
import textwrap
from datetime import datetime, timezone
from typing import Any

from google import genai
from google.genai import types


GEMINI_MODEL = "gemini-2.5-flash"


REQUEST_TIMEOUT_SECONDS = 90


def _build_prompt() -> str:
    today = datetime.now(timezone.utc).strftime("%A, %d %B %Y")
    return textwrap.dedent(f"""
        Today is {today} (UTC). Use Google Search to research the live market
        right now. Do NOT use any memorised or pre-training knowledge — every
        fact must come from a Google Search performed during this request.

        Task: act as a professional equity analyst and build a watchlist of
        exactly 5 US-listed stocks worth monitoring THIS day for DAYTRADING.

        Research requirements — search Google for ALL of these before answering:
        - Latest price action and volume for each pick (today or yesterday)
        - Recent earnings beats or misses published within the last 14 days
        - Breaking news catalysts: product launches, FDA decisions, M&A, macro events
        - Analyst upgrades or price-target changes from the last 7 days
        - Options market unusual activity or short-squeeze signals if present
        - Popular Stocks amongst daytraders at the moment

        Stock selection rules:
        1. US-listed only (NYSE, NASDAQ, or AMEX)
        2. Average daily volume > 500,000 shares
        3. At least 3 different sectors represented
        4. At least one LOW-risk and one HIGH-risk pick
        5. Each pick needs a concrete, dateable catalyst found via Google Search

        Output format — return ONLY a raw JSON array, no markdown fences,
        no preamble, no explanation:
        [
          {{
            "symbol":    "TICKER",
            "company":   "Full Company Name",
            "risk":      "LOW|MEDIUM|HIGH"
          }},
        ]
        r
    """).strip()


def _parse_watchlist(raw: str) -> list[dict[str, Any]]:
    cleaned = re.sub(r"```(?:json)?", "", raw, flags=re.IGNORECASE).strip()
    match = re.search(r"\[.*\]", cleaned, re.DOTALL)
    if match:
        cleaned = match.group(0)

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Could not parse Gemini response as JSON.\n"
            f"Raw response was:\n{raw}\n\nJSON error: {exc}"
        ) from exc

    if not isinstance(data, list):
        raise ValueError(f"Expected a JSON array, got: {type(data).__name__}")

    return data


def _extract_sources(response) -> list[str]:
    sources = []
    try:
        metadata = response.candidates[0].grounding_metadata
        if metadata and metadata.grounding_chunks:
            for chunk in metadata.grounding_chunks:
                if hasattr(chunk, "web") and chunk.web and chunk.web.uri:
                    sources.append(chunk.web.uri)
    except (AttributeError, IndexError):
        pass
    return sources


def _call_gemini(api_key: str) -> tuple[list[dict], list[str]]:

    client = genai.Client(api_key=api_key)

    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=_build_prompt(),
            config=types.GenerateContentConfig(
                tools=[types.Tool(google_search=types.GoogleSearch())],
                temperature=0.1,      
                max_output_tokens=8192,
            ),
        )
    except Exception as exc:
        raise RuntimeError(f"Gemini API call failed: {exc}") from exc

    raw = response.text
    if not raw:
        raise ValueError("Gemini returned an empty response.")

    sources = _extract_sources(response)
    watchlist = _parse_watchlist(raw)
    return watchlist, sources


def _normalise(raw_list: list[dict], sources: list[str]) -> list[dict[str, Any]]:
    return [
        {
            "symbol":  str(item.get("symbol",  "N/A")).upper().strip(),
            "company": str(item.get("company", "N/A")).strip(),
            "risk":    str(item.get("risk",    "N/A")).upper().strip(),
        }
        for item in raw_list
    ]

def get_watchlist(api_key: str | None = None) -> list[dict[str, Any]]:
    resolved_key = api_key or "ADD_KEY_HERE"
    if not resolved_key:
        raise EnvironmentError(
            "No Gemini API key found.\n"
        )

    raw_list, sources = _call_gemini(resolved_key)
    return _normalise(raw_list, sources)



if __name__ == "__main__":
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    print(f"\n📈  AI Stock Watchlist  (live Google Search data)  —  {timestamp}\n")
    print("   Searching the web via Gemini + Google Search grounding...\n")

    try:
        stocks = get_watchlist()
    except (EnvironmentError, RuntimeError, ValueError) as err:
        print(f"❌  Error: {err}")
        raise SystemExit(1)

    risk_icons = {"LOW": "🟢", "MEDIUM": "🟡", "HIGH": "🔴"}

    for i, s in enumerate(stocks, 1):
        icon = risk_icons.get(s["risk"], "⚪")
        print(f"  {i}. {icon} {s['symbol']:<6}  {s['company']}")
        print(f"       Risk   : {s['risk']}")
        print()
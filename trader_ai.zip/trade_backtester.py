"""
trade_backtester.py
===================
Runs a historical backtest after every live trade so you can continuously
monitor whether the strategy is performing as expected on real history.

Called automatically by trader_ai.py after each order is submitted.
Runs entirely in a background daemon thread — it never blocks live trading.

Architecture
------------
trader_ai.py
    └── trade_backtester.run_after_trade(symbol, capital)
            └── (daemon thread) backtester.backtest(symbol, ...)
                    └── daytrader._decide(...)   ← pure-history signal logic
                    └── daytrader._fetch_bars()  ← Alpaca historical data

File layout (all in the same folder):
    trader_ai.py
    trade_backtester.py   ← this file
    backtester.py         ← provided module (unchanged)
    daytrader.py          ← adapter for backtester.py
    API_KEY.txt
"""

from __future__ import annotations
import threading

import daytrader
from backtester import backtest, BacktestResult


# =============================================================================
#  CONFIGURATION
# =============================================================================

# Default backtest window and bar resolution.
# These can be changed before calling run_after_trade if needed.
DEFAULT_DAYS        = 30   # how many calendar days of history to use
DEFAULT_BAR_MINUTES = 5    # bar resolution in minutes

# Cap on how many backtest threads can run at once.
# Each thread fetches data and runs the engine; more than ~3 in parallel
# may hit Alpaca's data API rate limits.
_MAX_CONCURRENT = 3
_semaphore = threading.Semaphore(_MAX_CONCURRENT)


# =============================================================================
#  PUBLIC API
# =============================================================================

def configure(api_key: str, secret_key: str, feed: str = "sip") -> None:
    """
    Pass Alpaca credentials to the daytrader adapter.
    Must be called once (in trader_ai.main()) before any backtest runs.

    Parameters
    ----------
    api_key    : Alpaca API Key ID
    secret_key : Alpaca Secret Key
    feed       : data feed — "sip" for paper/live US equities (default)
    """
    daytrader.configure(api_key=api_key, secret_key=secret_key, feed=feed)


def run_after_trade(
    symbol:      str,
    capital:     float,
    days:        int = DEFAULT_DAYS,
    bar_minutes: int = DEFAULT_BAR_MINUTES,
) -> None:
    """
    Kick off a non-blocking backtest for `symbol` immediately after a trade.

    The result is printed to the terminal when the thread finishes.
    Live trading is never paused or delayed.

    Parameters
    ----------
    symbol      : stock ticker that was just traded (e.g. "NVDA")
    capital     : dollar amount to simulate with — use amount_per_trade so
                  the backtest reflects the same position size as live trades
    days        : number of calendar days of history to test over
    bar_minutes : bar resolution (5 = 5-minute bars)
    """
    thread = threading.Thread(
        target=_backtest_worker,
        args=(symbol, capital, days, bar_minutes),
        name=f"Backtest-{symbol}",
        daemon=True,   # dies automatically if main thread exits
    )
    thread.start()
    print(f"  [BACKTEST] {symbol}  backtest queued "
          f"({days}d × {bar_minutes}m bars, capital=${capital:,.2f})")


# =============================================================================
#  INTERNAL WORKER
# =============================================================================

def _backtest_worker(
    symbol:      str,
    capital:     float,
    days:        int,
    bar_minutes: int,
) -> None:
    """
    Worker function that runs inside the daemon thread.
    Uses a semaphore to limit concurrent Alpaca data fetches.
    """
    # Acquire a slot — wait if _MAX_CONCURRENT backtests are already running
    with _semaphore:
        print(f"\n[BACKTEST] ── Starting: {symbol} "
              f"({days}d, {bar_minutes}m bars) ──────────────────────")
        try:
            result = backtest(
                symbol,
                days=days,
                bar_minutes=bar_minutes,
                capital=capital,
                feed="sip",
            )
            _print_result(result)
        except Exception as e:
            print(f"[BACKTEST] {symbol} failed: {e}")


# =============================================================================
#  RESULT PRINTER
# =============================================================================

def _print_result(r: BacktestResult) -> None:
    """Print a clean, compact backtest summary to the terminal."""

    # Colour-code the return line: positive green (+), negative empty (-)
    ret_sign = "+" if r.total_return_pct >= 0 else ""

    # Profit factor label — gives a quick quality judgement
    if r.profit_factor == float("inf"):
        pf_label = "∞ (no losses)"
    elif r.profit_factor >= 2.0:
        pf_label = f"{r.profit_factor:.2f}  ✓ strong"
    elif r.profit_factor >= 1.0:
        pf_label = f"{r.profit_factor:.2f}  ~ marginal"
    else:
        pf_label = f"{r.profit_factor:.2f}  ✗ unprofitable"

    # Sharpe label
    if r.sharpe_approx >= 1.5:
        sharpe_label = f"{r.sharpe_approx:.2f}  ✓ good"
    elif r.sharpe_approx >= 0.5:
        sharpe_label = f"{r.sharpe_approx:.2f}  ~ acceptable"
    else:
        sharpe_label = f"{r.sharpe_approx:.2f}  ✗ poor"

    lines = [
        f"\n[BACKTEST] ┌── {r.symbol}  {r.start[:10]} → {r.end[:10]}  "
        f"({r.bar_minutes}m bars) ─────────────────",
        f"[BACKTEST] │  Capital:       ${r.starting_capital:>10,.2f}  →  "
        f"${r.ending_capital:>10,.2f}  ({ret_sign}{r.total_return_pct:.2f}%)",
        f"[BACKTEST] │  Trades:        {r.num_trades}  │  "
        f"Win rate: {r.win_rate:.1f}%",
        f"[BACKTEST] │  Avg win:       ${r.avg_win:>+9.2f}  │  "
        f"Avg loss: ${r.avg_loss:>+9.2f}",
        f"[BACKTEST] │  Profit factor: {pf_label}",
        f"[BACKTEST] │  Max drawdown:  {r.max_drawdown_pct:.2f}%",
        f"[BACKTEST] │  Sharpe:        {sharpe_label}",
        f"[BACKTEST] │  Total costs:   ${r.total_costs:.2f}",
        f"[BACKTEST] └─────────────────────────────────────────────────────\n",
    ]
    print("\n".join(lines))

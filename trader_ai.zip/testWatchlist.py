from Stock_Watchlist_Gemini import get_watchlist

watchlist = get_watchlist()
print(watchlist)
# check.py — diagnostic for the SIP error
import sys, os

# 1) Are we picking up the latest Action_Algorithm_Complex.py?
import Action_Algorithm_Complex
print("Action_Algorithm_Complex.py path:", Action_Algorithm_Complex.__file__)
print("default feed:", Action_Algorithm_Complex._default_feed)
print("has _resolve_feed:", hasattr(Action_Algorithm_Complex, "_resolve_feed"))

# 2) What version of alpaca-py is installed?
import alpaca
print("alpaca-py version:", alpaca.__version__)

from alpaca.data.enums import DataFeed
print("DataFeed.IEX:", DataFeed.IEX, "=", DataFeed.IEX.value)

# 3) Force a fresh call to analyze() and see what happens
import traceback
try:
    result = Action_Algorithm_Complex.analyze("WMT")
    print("SUCCESS:", result["signal"], result["confidence"])
except Exception as e:
    print("FAILED with:", type(e).__name__)
    traceback.print_exc()
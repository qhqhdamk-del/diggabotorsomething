"""
backtester.py
=============
Backtest daytrader's strategy against historical Alpaca bars.

Walks through historical OHLCV bar-by-bar, calling the SAME _decide()
function the live algorithm uses at each step. Tracks positions, exits,
realistic costs (commission + slippage), and reports performance.

Credentials
-----------
Uses the same Alpaca credentials as daytrader. By default these are read
from a text file named API_KEY.txt (API key on line 1, secret key on
line 2) next to the module or in the working directory. You can also call
configure(api_key=..., secret_key=...) or set environment variables.

Usage:
    from backtester import backtest, backtest_multiple

    # Single symbol
    result = backtest("AAPL", days=30, bar_minutes=5, capital=10_000)
    print(result.summary())

    # Multiple symbols
    results = backtest_multiple(["AAPL", "MSFT", "SPY"], days=30)

Cost assumptions (configurable):
    commission_per_share : $0.005  (Alpaca = $0 commissions, but rounded)
    slippage_bps         : 5       (0.05% per side; very generous on IEX)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional
import math

import numpy as np
import pandas as pd

import daytrader as dt
from daytrader import (
    _fetch_bars,   # we reuse the data fetcher
    _decide,       # we reuse the EXACT decision function
    configure,     # re-exported so callers can set credentials/feed here too
)


# ---------------------------------------------------------------------------
# Cost model — keep realistic, not optimistic. Bad backtests lie.
# ---------------------------------------------------------------------------

COMMISSION_PER_SHARE = 0.0   # Alpaca = commission-free for retail
SLIPPAGE_BPS = 5             # 0.05% slippage per fill (5 basis points)


@dataclass
class Trade:
    """One round-trip: entry -> exit."""
    symbol: str
    direction: str           # "BUY" (long) or "SELL" (short)
    entry_time: str
    exit_time: str
    entry_price: float
    exit_price: float
    shares: int
    gross_pnl: float         # before costs
    costs: float             # commission + slippage
    net_pnl: float           # after costs
    exit_reason: str         # "signal_flip", "stop_loss", "take_profit", "end_of_data"
    bars_held: int


@dataclass
class BacktestResult:
    """Output of a single-symbol backtest."""
    symbol: str
    start: str
    end: str
    bar_minutes: int
    starting_capital: float
    ending_capital: float
    trades: list[Trade] = field(default_factory=list)
    equity_curve: list[float] = field(default_factory=list)  # capital at each bar

    # Computed metrics
    @property
    def total_return_pct(self) -> float:
        if self.starting_capital == 0:
            return 0.0
        return 100 * (self.ending_capital - self.starting_capital) / self.starting_capital

    @property
    def num_trades(self) -> int:
        return len(self.trades)

    @property
    def win_rate(self) -> float:
        if not self.trades:
            return 0.0
        wins = sum(1 for t in self.trades if t.net_pnl > 0)
        return 100 * wins / len(self.trades)

    @property
    def avg_win(self) -> float:
        wins = [t.net_pnl for t in self.trades if t.net_pnl > 0]
        return sum(wins) / len(wins) if wins else 0.0

    @property
    def avg_loss(self) -> float:
        losses = [t.net_pnl for t in self.trades if t.net_pnl <= 0]
        return sum(losses) / len(losses) if losses else 0.0

    @property
    def profit_factor(self) -> float:
        """Sum of wins / |sum of losses|. >1 means net profitable."""
        wins = sum(t.net_pnl for t in self.trades if t.net_pnl > 0)
        losses = -sum(t.net_pnl for t in self.trades if t.net_pnl <= 0)
        if losses == 0:
            return float("inf") if wins > 0 else 0.0
        return wins / losses

    @property
    def max_drawdown_pct(self) -> float:
        """Worst peak-to-trough decline of the equity curve."""
        if not self.equity_curve:
            return 0.0
        equity = np.array(self.equity_curve)
        running_max = np.maximum.accumulate(equity)
        drawdowns = (equity - running_max) / running_max
        return float(abs(drawdowns.min()) * 100)

    @property
    def sharpe_approx(self) -> float:
        """Rough Sharpe ratio of bar-by-bar returns, annualized.

        Not a true Sharpe — uses bar returns not daily — but useful for
        comparison between strategies on the same data.
        """
        if len(self.equity_curve) < 2:
            return 0.0
        eq = np.array(self.equity_curve)
        returns = np.diff(eq) / eq[:-1]
        if returns.std() == 0:
            return 0.0
        # Approx bars per year for 5-min bars: 78 bars/day * 252 days ~= 19,656
        bars_per_year = (390 / self.bar_minutes) * 252
        return float(returns.mean() / returns.std() * math.sqrt(bars_per_year))

    @property
    def total_costs(self) -> float:
        return sum(t.costs for t in self.trades)

    def summary(self) -> str:
        lines = [
            f"=== {self.symbol} backtest ({self.start} → {self.end}) ===",
            f"  Bar size:            {self.bar_minutes}m",
            f"  Starting capital:    ${self.starting_capital:,.2f}",
            f"  Ending capital:      ${self.ending_capital:,.2f}",
            f"  Total return:        {self.total_return_pct:+.2f}%",
            f"  Trades:              {self.num_trades}",
            f"  Win rate:            {self.win_rate:.1f}%",
            f"  Avg win:             ${self.avg_win:+.2f}",
            f"  Avg loss:            ${self.avg_loss:+.2f}",
            f"  Profit factor:       {self.profit_factor:.2f}",
            f"  Max drawdown:        {self.max_drawdown_pct:.2f}%",
            f"  Sharpe (approx):     {self.sharpe_approx:.2f}",
            f"  Total trading costs: ${self.total_costs:.2f}",
        ]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Core backtest engine
# ---------------------------------------------------------------------------

def _fill_price(bar: pd.Series, side: str) -> float:
    """Realistic fill price: assume we fill at the next bar's open + slippage.

    side="BUY"  -> pay UP by slippage (worse for us)
    side="SELL" -> receive LESS by slippage
    """
    open_px = float(bar["open"])
    slip = open_px * (SLIPPAGE_BPS / 10_000)
    return open_px + slip if side == "BUY" else open_px - slip


def _trade_cost(shares: int, price: float, side: str) -> float:
    """Commission only; slippage is baked into the fill price."""
    return abs(shares) * COMMISSION_PER_SHARE


def backtest(
    symbol: str,
    days: int = 30,
    bar_minutes: int = 5,
    capital: float = 10_000.0,
    feed: Optional[str] = None,
    verbose: bool = False,
) -> BacktestResult:
    """
    Backtest the daytrader strategy on `symbol` over the last `days` calendar
    days using `bar_minutes` bars from Alpaca.

    Uses the EXACT same _decide() function the live algorithm uses, so the
    backtest reflects real production behavior (modulo data feed differences).

    Walks through bars one at a time. At each bar:
      1. Pass all bars up to (and including) this one to _decide()
      2. If the signal says ENTER/EXIT/CONTINUE, simulate the order at the
         NEXT bar's open (no look-ahead).
      3. Track P&L, costs, and equity curve.
    """
    # Fetch the full history we need
    df = _fetch_bars(symbol, bar_minutes, days, feed)

    if len(df) < dt.MIN_BARS_REQUIRED + 1:
        raise ValueError(
            f"Not enough history for backtest: {len(df)} bars, "
            f"need at least {dt.MIN_BARS_REQUIRED + 1}."
        )

    start_idx = dt.MIN_BARS_REQUIRED  # first bar we have enough history to decide on
    cash = capital
    position_shares = 0
    position_side: Optional[str] = None   # "BUY" or "SELL" or None
    position_entry_price = 0.0
    position_entry_time = ""
    position_entry_bar = 0
    position_stop_loss = 0.0
    position_take_profit = 0.0
    prior_position: Optional[str] = None

    trades: list[Trade] = []
    equity_curve: list[float] = []

    for i in range(start_idx, len(df) - 1):    # leave one bar for the fill
        window = df.iloc[: i + 1]
        bar = df.iloc[i]
        next_bar = df.iloc[i + 1]

        # Mark-to-market equity at this bar's close
        mtm = 0.0
        if position_side == "BUY":
            mtm = position_shares * (float(bar["close"]) - position_entry_price)
        elif position_side == "SELL":
            mtm = position_shares * (position_entry_price - float(bar["close"]))
        equity_curve.append(cash + mtm)

        # --- Check stop-loss / take-profit FIRST, before strategy ---
        # If price hit our stop or target during this bar, exit at that level.
        forced_exit = None
        forced_price = None
        if position_side == "BUY":
            if float(bar["low"]) <= position_stop_loss:
                forced_exit = "stop_loss"
                forced_price = position_stop_loss
            elif float(bar["high"]) >= position_take_profit:
                forced_exit = "take_profit"
                forced_price = position_take_profit
        elif position_side == "SELL":
            if float(bar["high"]) >= position_stop_loss:
                forced_exit = "stop_loss"
                forced_price = position_stop_loss
            elif float(bar["low"]) <= position_take_profit:
                forced_exit = "take_profit"
                forced_price = position_take_profit

        if forced_exit is not None:
            # Close at the stop/target level
            exit_side = "SELL" if position_side == "BUY" else "BUY"
            costs = _trade_cost(position_shares, forced_price, exit_side)
            if position_side == "BUY":
                gross = position_shares * (forced_price - position_entry_price)
            else:
                gross = position_shares * (position_entry_price - forced_price)
            net = gross - costs
            cash += net

            trades.append(Trade(
                symbol=symbol,
                direction=position_side,
                entry_time=position_entry_time,
                exit_time=bar.name.isoformat() if hasattr(bar.name, "isoformat") else str(bar.name),
                entry_price=position_entry_price,
                exit_price=forced_price,
                shares=position_shares,
                gross_pnl=gross,
                costs=costs,
                net_pnl=net,
                exit_reason=forced_exit,
                bars_held=i - position_entry_bar,
            ))

            if verbose:
                print(f"  {bar.name} {forced_exit.upper()} {position_side} {position_shares}@{forced_price:.2f} P&L=${net:+.2f}")

            # Position closed
            position_shares = 0
            position_side = None
            prior_position = None
            continue

        # --- Run strategy ---
        try:
            decision = _decide(symbol, window, cash, prior_position)
        except Exception:
            continue

        action = decision["action"]
        signal = decision["signal"]

        if action == "ENTER":
            # Open a new position at the NEXT bar's open (no look-ahead)
            shares = decision["shares"]
            if shares <= 0:
                continue
            fill_px = _fill_price(next_bar, signal)
            costs = _trade_cost(shares, fill_px, signal)
            cash -= costs

            position_shares = shares
            position_side = signal
            position_entry_price = fill_px
            position_entry_time = next_bar.name.isoformat() if hasattr(next_bar.name, "isoformat") else str(next_bar.name)
            position_entry_bar = i + 1
            position_stop_loss = decision["stop_loss"]
            position_take_profit = decision["take_profit"]
            prior_position = signal

            if verbose:
                print(f"  {next_bar.name} ENTER {signal} {shares}@{fill_px:.2f} stop={position_stop_loss:.2f}")

        elif action == "EXIT":
            # Close position at next bar's open
            exit_side = "SELL" if position_side == "BUY" else "BUY"
            fill_px = _fill_price(next_bar, exit_side)
            costs = _trade_cost(position_shares, fill_px, exit_side)
            if position_side == "BUY":
                gross = position_shares * (fill_px - position_entry_price)
            else:
                gross = position_shares * (position_entry_price - fill_px)
            net = gross - costs
            cash += net

            trades.append(Trade(
                symbol=symbol,
                direction=position_side,
                entry_time=position_entry_time,
                exit_time=next_bar.name.isoformat() if hasattr(next_bar.name, "isoformat") else str(next_bar.name),
                entry_price=position_entry_price,
                exit_price=fill_px,
                shares=position_shares,
                gross_pnl=gross,
                costs=costs,
                net_pnl=net,
                exit_reason="signal_flip",
                bars_held=(i + 1) - position_entry_bar,
            ))

            if verbose:
                print(f"  {next_bar.name} EXIT  {position_side} {position_shares}@{fill_px:.2f} P&L=${net:+.2f}")

            position_shares = 0
            position_side = None
            prior_position = None

        elif action == "CONTINUE":
            pass  # just keep the position

    # Force-close any open position at the end
    if position_side is not None:
        last_bar = df.iloc[-1]
        fill_px = float(last_bar["close"])
        exit_side = "SELL" if position_side == "BUY" else "BUY"
        costs = _trade_cost(position_shares, fill_px, exit_side)
        if position_side == "BUY":
            gross = position_shares * (fill_px - position_entry_price)
        else:
            gross = position_shares * (position_entry_price - fill_px)
        net = gross - costs
        cash += net

        trades.append(Trade(
            symbol=symbol,
            direction=position_side,
            entry_time=position_entry_time,
            exit_time=last_bar.name.isoformat() if hasattr(last_bar.name, "isoformat") else str(last_bar.name),
            entry_price=position_entry_price,
            exit_price=fill_px,
            shares=position_shares,
            gross_pnl=gross,
            costs=costs,
            net_pnl=net,
            exit_reason="end_of_data",
            bars_held=len(df) - 1 - position_entry_bar,
        ))

    equity_curve.append(cash)

    return BacktestResult(
        symbol=symbol,
        start=df.index[0].isoformat() if hasattr(df.index[0], "isoformat") else str(df.index[0]),
        end=df.index[-1].isoformat() if hasattr(df.index[-1], "isoformat") else str(df.index[-1]),
        bar_minutes=bar_minutes,
        starting_capital=capital,
        ending_capital=cash,
        trades=trades,
        equity_curve=equity_curve,
    )


def backtest_multiple(
    symbols: list[str],
    days: int = 30,
    bar_minutes: int = 5,
    capital_per_symbol: float = 10_000.0,
    feed: Optional[str] = None,
    verbose: bool = False,
) -> dict[str, BacktestResult]:
    """Run backtest() against each symbol independently."""
    results = {}
    for sym in symbols:
        try:
            r = backtest(sym, days=days, bar_minutes=bar_minutes,
                         capital=capital_per_symbol, feed=feed, verbose=verbose)
            results[sym] = r
            print(r.summary())
            print()
        except Exception as e:
            print(f"!!! {sym} failed: {e}\n")
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    syms = sys.argv[1:] if len(sys.argv) > 1 else ["AAPL", "MSFT", "SPY"]
    results = backtest_multiple(syms, days=30, bar_minutes=5)

    # Combined summary
    if results:
        total_start = sum(r.starting_capital for r in results.values())
        total_end = sum(r.ending_capital for r in results.values())
        total_trades = sum(r.num_trades for r in results.values())
        all_pnls = [t.net_pnl for r in results.values() for t in r.trades]
        wins = sum(1 for p in all_pnls if p > 0)
        print("\n=== Aggregate ===")
        print(f"  Total return: {100*(total_end-total_start)/total_start:+.2f}%")
        print(f"  Total trades: {total_trades}")
        if total_trades:
            print(f"  Combined win rate: {100*wins/total_trades:.1f}%")

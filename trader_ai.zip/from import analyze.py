from Action_Algorithm_Complex import analyze
result = analyze("AAPL")  # or whatever symbol you've been testing
print(f"signal: {result['signal']}")
print(f"confidence: {result['confidence']}")
print(f"composite: {result['reasoning']['composite']}")
print(f"blended: {result['reasoning']['blended']}")
print(f"veto: {result['reasoning']['veto']}")
print(f"regime: {result['reasoning']['regime']}")
print(f"vol_dampener: {result['reasoning']['vol_dampener']}")
print(f"atr_pct: {result['reasoning']['atr_pct']}")
print(f"slope: {result['reasoning']['slope_pct_10bar']}")
print(f"above_50ema: {result['reasoning']['above_50ema']}")
"""
=============================================================================
  Simple Stock Trading Bot using Alpaca Markets API
=============================================================================

SETUP INSTRUCTIONS
------------------
1. CREATE A FREE ALPACA ACCOUNT:
   - Go to https://alpaca.markets and click "Sign Up"
   - Complete email verification
   - You get a Paper Trading account immediately (no deposit needed)
   - For live trading: complete identity verification and fund your account

2. GET YOUR API KEYS:
   Paper Trading keys:
   - Log in → go to https://app.alpaca.markets/paper/dashboard/overview
   - Click "Your API Keys" (right sidebar) → "Generate New Key"
   - Copy your API Key ID and Secret Key

   Live Trading keys (only when ready for real money):
   - Go to https://app.alpaca.markets/live/dashboard/overview
   - Same process as above

3. INSTALL DEPENDENCIES:
   pip install alpaca-py

4. API KEY SETUP (two options — pick one):

   Option A — File (recommended, no re-entry needed):
   Create a file called "API_KEY.txt" in the same folder as this script.
   The file must have exactly two lines:
       Line 1: your API Key ID
       Line 2: your Secret Key
   Example contents of API_KEY.txt:
       PKXXXXXXXXXXXXXXXXXXXXXXXX
       xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

   Option B — Enter keys at runtime:
   If API_KEY.txt is not found, the program will ask you to type
   your keys each time it runs.

5. RUN THE PROGRAM:
   python trading_bot.py

=============================================================================
"""

from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderStatus
import time
import os

# =============================================================================
#  CONFIGURATION — Edit these values before running
# =============================================================================

# Name of the file where API keys are stored (must be in the same folder)
API_KEY_FILE = "API_KEY.txt"

# Set to True to use real money (live trading).
# WARNING: Live trading uses REAL funds. Only change this when you are ready.
LIVE_TRADING = False

# How long to wait (in seconds) between order status checks
ORDER_POLL_INTERVAL = 2

# Maximum total seconds to wait for an order to fill before giving up
ORDER_TIMEOUT = 60

# =============================================================================
#  FUNCTIONS
# =============================================================================

def load_api_keys() -> tuple[str, str]:
    """
    Load the Alpaca API key and secret from API_KEY.txt if it exists,
    otherwise prompt the user to enter them manually.

    The expected format of API_KEY.txt is two plain-text lines:
        Line 1: API Key ID
        Line 2: Secret Key

    Returns
    -------
    (api_key, secret_key) as a tuple of strings.
    """
    # Build the full path to API_KEY.txt relative to this script's location.
    # Using __file__ ensures we look in the script's folder, not wherever
    # the user happens to run the command from.
    script_dir   = os.path.dirname(os.path.abspath(__file__))
    key_file_path = os.path.join(script_dir, API_KEY_FILE)

    if os.path.exists(key_file_path):
        # --- File found: read keys from it ---
        print(f"[INFO] Found {API_KEY_FILE} — loading API keys from file.")
        try:
            with open(key_file_path, "r") as f:
                # Read all non-empty lines (strips whitespace/newlines)
                lines = [line.strip() for line in f.readlines() if line.strip()]

            if len(lines) < 2:
                print(f"[ERROR] {API_KEY_FILE} must contain exactly two lines:")
                print("        Line 1: API Key ID")
                print("        Line 2: Secret Key")
                raise SystemExit(1)

            api_key    = lines[0]
            secret_key = lines[1]

            # Basic sanity check — Alpaca paper keys start with "PK",
            # live keys start with "AK". Warn but don't block.
            if not (api_key.startswith("PK") or api_key.startswith("AK")):
                print("[WARNING] API key does not start with 'PK' or 'AK'. "
                      "Double-check your key in API_KEY.txt.")

            print("[INFO] API keys loaded successfully from file.")
            return api_key, secret_key

        except OSError as e:
            print(f"[ERROR] Could not read {API_KEY_FILE}: {e}")
            raise SystemExit(1)

    else:
        # --- File not found: ask the user to enter keys manually ---
        print(f"[INFO] {API_KEY_FILE} not found in {script_dir}")
        print("[INFO] Please enter your Alpaca API keys.")
        print("       They will be saved automatically so you won't be asked again.\n")

        while True:
            api_key = input("  Enter your API Key ID : ").strip()
            if api_key:
                break
            print("  [ERROR] API Key ID cannot be empty.")

        while True:
            secret_key = input("  Enter your Secret Key : ").strip()
            if secret_key:
                break
            print("  [ERROR] Secret Key cannot be empty.")

        # Save the keys automatically for all future runs
        try:
            with open(key_file_path, "w") as f:
                f.write(f"{api_key}\n{secret_key}\n")
            print(f"\n[INFO] Keys saved to {key_file_path}")
            print("[INFO] Keep this file private — do not share or commit it to Git.")
        except OSError as e:
            print(f"[WARNING] Could not save keys to file: {e}")
            print("[WARNING] You will be asked to enter your keys again next run.")

        return api_key, secret_key


def create_client(api_key: str, secret_key: str) -> TradingClient:
    """
    Create and return an Alpaca TradingClient.

    - paper=True  -> connects to the paper trading sandbox (fake money, safe)
    - paper=False -> connects to live trading (real money, be careful!)
    """
    paper_mode = not LIVE_TRADING          # paper=True when LIVE_TRADING=False
    mode_label = "LIVE" if LIVE_TRADING else "PAPER"
    print(f"[INFO] Connecting to Alpaca in {mode_label} trading mode...")

    client = TradingClient(
        api_key=api_key,
        secret_key=secret_key,
        paper=paper_mode
    )
    return client


def print_account_info(client: TradingClient) -> None:
    """Fetch and display basic account details (buying power, portfolio value)."""
    try:
        account = client.get_account()
        print("\n-- Account Summary ------------------------------------------")
        print(f"  Status         : {account.status}")
        print(f"  Buying Power   : ${float(account.buying_power):,.2f}")
        print(f"  Portfolio Value: ${float(account.portfolio_value):,.2f}")
        print("-------------------------------------------------------------\n")
    except Exception as e:
        print(f"[WARNING] Could not fetch account info: {e}")


def print_positions(client: TradingClient) -> None:
    """Fetch and display all current open positions."""
    try:
        positions = client.get_all_positions()
        print("\n-- Current Positions ----------------------------------------")
        if not positions:
            print("  (no open positions)")
        else:
            for pos in positions:
                print(
                    f"  {pos.symbol:6s}  qty={pos.qty:>8}  "
                    f"avg_entry=${float(pos.avg_entry_price):>10,.4f}  "
                    f"market_value=${float(pos.market_value):>12,.2f}  "
                    f"unrealized_pl=${float(pos.unrealized_pl):>10,.2f}"
                )
        print("-------------------------------------------------------------\n")
    except Exception as e:
        print(f"[WARNING] Could not fetch positions: {e}")


def submit_market_order(
    client: TradingClient,
    symbol: str,
    qty: float,
    side: OrderSide
) -> None:
    """
    Submit a market order and wait for it to fill.

    Parameters
    ----------
    client : TradingClient   - authenticated Alpaca client
    symbol : str             - stock ticker, e.g. "AAPL"
    qty    : float           - number of shares (can be fractional)
    side   : OrderSide       - OrderSide.BUY or OrderSide.SELL
    """

    # Build the order request
    order_request = MarketOrderRequest(
        symbol=symbol,
        qty=qty,
        side=side,
        time_in_force=TimeInForce.DAY   # Good-for-day market order
    )

    print(f"\n[INFO] Submitting {side.value.upper()} market order: {qty} share(s) of {symbol}...")

    try:
        # Submit the order to Alpaca
        order = client.submit_order(order_request)
        print(f"[INFO] Order accepted. Order ID: {order.id}")
    except Exception as e:
        print(f"[ERROR] Failed to submit order: {e}")
        return

    # Poll until the order is filled or times out
    elapsed = 0
    while elapsed < ORDER_TIMEOUT:
        try:
            # Refresh order data from the API
            order = client.get_order_by_id(order.id)
        except Exception as e:
            print(f"[ERROR] Could not retrieve order status: {e}")
            return

        status = order.status
        print(f"[INFO] Order status: {status.value}  (waited {elapsed}s)")

        if status == OrderStatus.FILLED:
            # Order fully filled — print results
            print("\n-- Order Result ---------------------------------------------")
            print(f"  Status           : {status.value.upper()}")
            print(f"  Symbol           : {order.symbol}")
            print(f"  Side             : {order.side.value.upper()}")
            print(f"  Requested Qty    : {order.qty}")
            print(f"  Filled Qty       : {order.filled_qty}")
            avg_price = float(order.filled_avg_price) if order.filled_avg_price else 0.0
            print(f"  Avg Fill Price   : ${avg_price:,.4f}")
            total_value = float(order.filled_qty) * avg_price
            print(f"  Total Value      : ${total_value:,.2f}")
            print("-------------------------------------------------------------")
            return

        elif status in (OrderStatus.CANCELED, OrderStatus.EXPIRED, OrderStatus.REJECTED):
            # Something went wrong on the broker side
            print(f"[WARNING] Order ended with status: {status.value.upper()}")
            return

        # Wait before checking again
        time.sleep(ORDER_POLL_INTERVAL)
        elapsed += ORDER_POLL_INTERVAL

    print(f"[WARNING] Order did not fill within {ORDER_TIMEOUT} seconds.")
    print(f"          Last known status: {order.status.value}")
    print("          The order may still be pending. Check your Alpaca dashboard.")


def get_valid_ticker() -> str:
    """Prompt the user for a stock ticker and return it uppercased."""
    while True:
        ticker = input("Enter stock ticker (e.g. AAPL, TSLA, MSFT): ").strip().upper()
        if ticker.isalpha() and 1 <= len(ticker) <= 5:
            return ticker
        print("[ERROR] Invalid ticker. Please use 1-5 letters only (e.g. AAPL).")


def get_valid_quantity() -> float:
    """Prompt the user for a share quantity and return it as a float."""
    while True:
        qty_str = input("Enter number of shares (e.g. 1, 0.5, 10): ").strip()
        try:
            qty = float(qty_str)
            if qty > 0:
                return qty
            print("[ERROR] Quantity must be greater than zero.")
        except ValueError:
            print("[ERROR] Please enter a valid number.")


def get_valid_side() -> OrderSide:
    """Prompt the user for buy/sell and return the corresponding OrderSide."""
    while True:
        action = input("Action - buy or sell? ").strip().lower()
        if action == "buy":
            return OrderSide.BUY
        elif action == "sell":
            return OrderSide.SELL
        else:
            print("[ERROR] Please type 'buy' or 'sell'.")


# =============================================================================
#  MAIN
# =============================================================================

def main() -> None:
    """Entry point: gather input, place the order, and show results."""

    print("=" * 55)
    print("  Alpaca Simple Trading Bot")
    mode = "LIVE (REAL MONEY)" if LIVE_TRADING else "PAPER (simulated)"
    print(f"  Mode: {mode}")
    print("=" * 55)

    # Load API keys from file or prompt the user
    api_key, secret_key = load_api_keys()

    # Extra confirmation for live trading to prevent accidental real-money trades
    if LIVE_TRADING:
        print("\n[WARNING] LIVE_TRADING is True - this will use REAL MONEY.")
        confirm = input("   Type 'yes' to continue, anything else to abort: ").strip().lower()
        if confirm != "yes":
            print("[INFO] Aborted.")
            return

    # Connect to Alpaca using the loaded keys
    try:
        client = create_client(api_key, secret_key)
    except Exception as e:
        print(f"[ERROR] Could not create Alpaca client: {e}")
        return

    # Show account buying power before placing the order
    print_account_info(client)

    # Gather order details from the user
    print("-- Order Details --------------------------------------------")
    symbol = get_valid_ticker()
    qty    = get_valid_quantity()
    side   = get_valid_side()

    print(f"\n[INFO] Preparing to {side.value.upper()} {qty} share(s) of {symbol}.")

    # Submit the market order and wait for it to fill
    submit_market_order(client, symbol, qty, side)

    # Show all positions after the trade
    print_positions(client)

    print("[INFO] Done. Check your Alpaca dashboard for full trade history.")


if __name__ == "__main__":
    main()


    
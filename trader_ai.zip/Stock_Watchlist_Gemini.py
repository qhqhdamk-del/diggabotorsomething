"""
stock_watchlist.py
==================
Every call to get_watchlist() fires a fresh Google Gemini request that
uses Grounding with Google Search to fetch live market data and return
5 stock picks based entirely on current web information.

Setup
-----
1. Get a FREE API key (no credit card) at https://aistudio.google.com
   → Click "Get API key" → "Create API key"

2. Install the dependency:
       pip install google-genai

3. Set your key (pick one method):
       a) Environment variable (recommended):
              export GEMINI_API_KEY="AIza..."
       b) .env file in your project root (requires python-dotenv):
              GEMINI_API_KEY=AIza...
       c) Pass it directly at call time:
              get_watchlist(api_key="AIza...")

Usage
-----
    from stock_watchlist import get_watchlist

    watchlist = get_watchlist()
    for stock in watchlist:
        print(stock["symbol"], "—", stock["rationale"])

Return value
------------
A list of 5 dicts, each with:
    symbol      str   Ticker, e.g. "NVDA"
    company     str   Full company name
    rationale   str   Why it was picked — grounded in a live web source
    sector      str   Industry sector
    risk        str   "LOW", "MEDIUM", or "HIGH"
    sources     list  URLs Google Search used to ground the response
"""

from __future__ import annotations

import json
import os
import re
import textwrap
from datetime import datetime, timezone
from typing import Any

from google import genai
from google.genai import types

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# gemini-2.5-flash: free tier, fast, supports Google Search grounding
GEMINI_MODEL = "gemini-2.5-flash"


REQUEST_TIMEOUT_SECONDS = 90


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------

def _build_prompt() -> str:
    today = datetime.now(timezone.utc).strftime("%A, %d %B %Y")
    return textwrap.dedent(f"""
        Today is {today} (UTC). Use Google Search to research the live market
        right now. Do NOT use any memorised or pre-training knowledge — every
        fact must come from a Google Search performed during this request.

        Task: act as a professional equity analyst and build a watchlist of
        exactly 5 US-listed stocks worth monitoring THIS day for DAYTRADING.

        Research requirements — search Google for ALL of these before answering:
        - Latest price action and volume for each pick (today or yesterday)
        - Recent earnings beats or misses published within the last 14 days
        - Breaking news catalysts: product launches, FDA decisions, M&A, macro events
        - Analyst upgrades or price-target changes from the last 7 days
        - Options market unusual activity or short-squeeze signals if present
        - Popular Stocks amongst daytraders at the moment

        Stock selection rules:
        1. US-listed only (NYSE, NASDAQ, or AMEX)
        2. Average daily volume > 500,000 shares
        3. At least 3 different sectors represented
        4. At least one LOW-risk and one HIGH-risk pick
        5. Each pick needs a concrete, dateable catalyst found via Google Search

        Output format — return ONLY a raw JSON array, no markdown fences,
        no preamble, no explanation:
        [
          {{
            "symbol":    "TICKER",
            "company":   "Full Company Name",
            "risk":      "LOW|MEDIUM|HIGH"
          }},
        ]
        r
    """).strip()


# ---------------------------------------------------------------------------
# JSON parser (resilient to markdown fences Gemini sometimes adds)
# ---------------------------------------------------------------------------

def _parse_watchlist(raw: str) -> list[dict[str, Any]]:
    cleaned = re.sub(r"```(?:json)?", "", raw, flags=re.IGNORECASE).strip()
    match = re.search(r"\[.*\]", cleaned, re.DOTALL)
    if match:
        cleaned = match.group(0)

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Could not parse Gemini response as JSON.\n"
            f"Raw response was:\n{raw}\n\nJSON error: {exc}"
        ) from exc

    if not isinstance(data, list):
        raise ValueError(f"Expected a JSON array, got: {type(data).__name__}")

    return data


# ---------------------------------------------------------------------------
# Extract grounding source URLs from Gemini response metadata
# ---------------------------------------------------------------------------

def _extract_sources(response) -> list[str]:
    sources = []
    try:
        metadata = response.candidates[0].grounding_metadata
        if metadata and metadata.grounding_chunks:
            for chunk in metadata.grounding_chunks:
                if hasattr(chunk, "web") and chunk.web and chunk.web.uri:
                    sources.append(chunk.web.uri)
    except (AttributeError, IndexError):
        pass
    return sources


# ---------------------------------------------------------------------------
# Gemini API call
# ---------------------------------------------------------------------------

def _call_gemini(api_key: str) -> tuple[list[dict], list[str]]:
    """
    Call Gemini 2.5 Flash with Google Search grounding enabled.
    Every call performs real-time Google Searches to ground the response.
    """
    client = genai.Client(api_key=api_key)

    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=_build_prompt(),
            config=types.GenerateContentConfig(
                tools=[types.Tool(google_search=types.GoogleSearch())],
                temperature=0.1,      # low = factual, consistent output
                max_output_tokens=8192,
            ),
        )
    except Exception as exc:
        raise RuntimeError(f"Gemini API call failed: {exc}") from exc

    raw = response.text
    if not raw:
        raise ValueError("Gemini returned an empty response.")

    sources = _extract_sources(response)
    watchlist = _parse_watchlist(raw)
    return watchlist, sources


# ---------------------------------------------------------------------------
# Normalise output
# ---------------------------------------------------------------------------

def _normalise(raw_list: list[dict], sources: list[str]) -> list[dict[str, Any]]:
    return [
        {
            "symbol":  str(item.get("symbol",  "N/A")).upper().strip(),
            "company": str(item.get("company", "N/A")).strip(),
            "risk":    str(item.get("risk",    "N/A")).upper().strip(),
        }
        for item in raw_list
    ]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_watchlist(api_key: str | None = None) -> list[dict[str, Any]]:
    """
    Fetch a fresh AI-generated stock watchlist using Google Gemini Flash
    with Grounding with Google Search enabled.

    Google Search grounding means every response is backed by live web
    searches — you get real-time market data and news on every call.

    Parameters
    ----------
    api_key : str, optional
        Your Gemini API key. If omitted, reads GEMINI_API_KEY from the
        environment (or a .env file loaded with python-dotenv).
        Free key at: https://aistudio.google.com

    Returns
    -------
    list[dict]  — exactly 5 items, each with keys:
        symbol    : str  — e.g. "NVDA"
        company   : str  — e.g. "NVIDIA Corporation"
        rationale : str  — specific recent catalyst with date
        sector    : str  — e.g. "Technology"
        risk      : str  — "LOW", "MEDIUM", or "HIGH"
        sources   : list — URLs Google searched to ground this response
    """
    resolved_key = api_key or "AIzaSyDbkewQdZTqVqMWL2KEau-Ho42-1uuPaIc"
    if not resolved_key:
        raise EnvironmentError(
            "No Gemini API key found.\n"
            "  Option 1 — environment variable:  export GEMINI_API_KEY='AIza...'\n"
            "  Option 2 — pass directly:          get_watchlist(api_key='AIza...')\n"
            "  Get a free key at: https://aistudio.google.com"
        )

    raw_list, sources = _call_gemini(resolved_key)
    return _normalise(raw_list, sources)


# ---------------------------------------------------------------------------
# Run from the command line:  python stock_watchlist.py
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    print(f"\n📈  AI Stock Watchlist  (live Google Search data)  —  {timestamp}\n")
    print("   Searching the web via Gemini + Google Search grounding...\n")

    try:
        stocks = get_watchlist()
    except (EnvironmentError, RuntimeError, ValueError) as err:
        print(f"❌  Error: {err}")
        raise SystemExit(1)

    risk_icons = {"LOW": "🟢", "MEDIUM": "🟡", "HIGH": "🔴"}

    for i, s in enumerate(stocks, 1):
        icon = risk_icons.get(s["risk"], "⚪")
        print(f"  {i}. {icon} {s['symbol']:<6}  {s['company']}")
        print(f"       Risk   : {s['risk']}")
        print()
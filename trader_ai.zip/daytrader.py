"""
daytrader.py
============
Adapter module that bridges backtester.py to the trader_ai strategy.

backtester.py was written expecting a "daytrader" module that exposes:
    configure(api_key, secret_key, feed)
    _fetch_bars(symbol, bar_minutes, days, feed) → pd.DataFrame
    _decide(symbol, window, cash, prior_position) → action dict
    MIN_BARS_REQUIRED: int

This file provides exactly those. All indicator maths inside _decide()
use only the historical `window` DataFrame passed in by the backtester
loop — no live API calls are made during a backtest run.

Signal logic mirrors Action_Algorithm_Simple (MA crossover + RSI) and
Action_Algorithm_Complex (ATR-based stop-loss and take-profit).
"""

from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Optional
import math

import numpy as np
import pandas as pd

from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit


# =============================================================================
#  CONSTANTS
# =============================================================================

# Minimum bars needed before _decide() can produce a reliable signal.
# Must cover the longest MA period plus the RSI warmup.
MIN_BARS_REQUIRED = 65

# Moving-average periods — kept in sync with Action_Algorithm_Simple
_SHORT_MA  = 20
_LONG_MA   = 50
_RSI_PERIOD = 14

# ATR multipliers for stop-loss and take-profit legs
# (mirrors Action_Algorithm_Complex bracket sizing)
_ATR_PERIOD = 14
_ATR_STOP   = 2.0   # stop-loss  = entry ± 2 × ATR
_ATR_TP     = 3.0   # take-profit = entry ± 3 × ATR  (1.5 : 1 R:R)


# =============================================================================
#  CREDENTIALS  (populated by configure())
# =============================================================================

_api_key:    str = ""
_secret_key: str = ""
_feed:       str = "sip"


def configure(
    api_key:    str = "",
    secret_key: str = "",
    feed:       str = "sip",
) -> None:
    """
    Store Alpaca API credentials for _fetch_bars.
    Call this once before running any backtest.
    """
    global _api_key, _secret_key, _feed
    _api_key    = api_key
    _secret_key = secret_key
    _feed       = feed


# =============================================================================
#  DATA FETCHER
# =============================================================================

def _fetch_bars(
    symbol:      str,
    bar_minutes: int,
    days:        int,
    feed:        Optional[str] = None,
) -> pd.DataFrame:
    """
    Fetch OHLCV bars from Alpaca for `symbol` over the last `days` calendar
    days at `bar_minutes` resolution.

    Returns a DataFrame sorted by timestamp, indexed by datetime, with
    columns: open, high, low, close, volume.
    """
    if not _api_key:
        raise RuntimeError(
            "Credentials not set. Call daytrader.configure(api_key, secret_key) first."
        )

    client = StockHistoricalDataClient(
        api_key=_api_key,
        secret_key=_secret_key,
    )

    # Map bar_minutes to an Alpaca TimeFrame
    tf = TimeFrame(bar_minutes, TimeFrameUnit.Minute)

    end   = datetime.now(tz=timezone.utc)
    start = end - timedelta(days=days)

    request = StockBarsRequest(
        symbol_or_symbols=symbol,
        timeframe=tf,
        start=start,
        end=end,
        feed=feed or _feed,
    )

    bars = client.get_stock_bars(request)
    df   = bars.df

    # Alpaca returns a MultiIndex (symbol, timestamp) — drop the symbol level
    if isinstance(df.index, pd.MultiIndex):
        df = df.xs(symbol, level="symbol")

    df.index.name = "timestamp"
    df = df[["open", "high", "low", "close", "volume"]].copy()
    df = df.sort_index()
    return df


# =============================================================================
#  INDICATOR HELPERS
# =============================================================================

def _compute_rsi(close: pd.Series, period: int = 14) -> float:
    """
    Exponentially smoothed RSI (Wilder method).
    Returns the latest RSI value as a float.
    """
    delta  = close.diff().dropna()
    gain   = delta.clip(lower=0)
    loss   = (-delta).clip(lower=0)
    avg_g  = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_l  = loss.ewm(com=period - 1, min_periods=period).mean()
    rs     = avg_g / avg_l.replace(0, np.nan)
    rsi    = 100 - (100 / (1 + rs))
    return float(rsi.iloc[-1])


def _compute_atr(window: pd.DataFrame, period: int = 14) -> float:
    """
    Exponentially smoothed Average True Range.
    True Range = max(H-L, |H-prev_C|, |L-prev_C|).
    """
    high       = window["high"]
    low        = window["low"]
    close      = window["close"]
    prev_close = close.shift(1)

    tr = pd.concat(
        [high - low,
         (high - prev_close).abs(),
         (low  - prev_close).abs()],
        axis=1,
    ).max(axis=1)

    atr = tr.ewm(com=period - 1, min_periods=period).mean()
    return float(atr.iloc[-1])


# =============================================================================
#  DECISION FUNCTION
# =============================================================================

def _decide(
    symbol:         str,
    window:         pd.DataFrame,
    cash:           float,
    prior_position: Optional[str],
) -> dict:
    """
    Decide whether to ENTER, EXIT, or CONTINUE based on historical bars.

    This is called once per bar inside the backtester loop. All calculations
    use only `window` — no live market data is fetched here.

    Signal logic
    ------------
    Short MA > Long MA  AND  RSI < 70  →  BUY
    Short MA < Long MA  AND  RSI > 30  →  SELL
    Otherwise                          →  HOLD

    Action mapping
    --------------
    No position  +  BUY / SELL  →  ENTER  (open a new position)
    No position  +  HOLD        →  CONTINUE  (stay flat)
    In position  +  same signal →  CONTINUE  (hold the position)
    In position  +  flipped     →  EXIT   (close; re-entry considered next bar)

    Stop-loss / take-profit (ENTER only)
    -------------------------------------
    BUY:   stop = entry − ATR_STOP × ATR,  tp = entry + ATR_TP × ATR
    SELL:  stop = entry + ATR_STOP × ATR,  tp = entry − ATR_TP × ATR

    Parameters
    ----------
    symbol         : stock ticker (not used for calculations — kept for signature)
    window         : DataFrame slice from bar 0 up to (and including) current bar
    cash           : current simulated cash balance (used to size the position)
    prior_position : "BUY", "SELL", or None

    Returns
    -------
    dict with keys:
        action      – "ENTER" | "EXIT" | "CONTINUE"
        signal      – "BUY"  | "SELL"
        shares      – int (0 for EXIT / CONTINUE)
        stop_loss   – float
        take_profit – float
    """
    close = window["close"]

    # Not enough bars yet — stay flat
    if len(close) < _LONG_MA + _RSI_PERIOD:
        return {
            "action": "CONTINUE", "signal": prior_position or "BUY",
            "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
        }

    short_ma = float(close.tail(_SHORT_MA).mean())
    long_ma  = float(close.tail(_LONG_MA).mean())
    rsi      = _compute_rsi(close, _RSI_PERIOD)
    atr      = _compute_atr(window, _ATR_PERIOD)
    price    = float(close.iloc[-1])

    # ── Derive raw signal ─────────────────────────────────────────────
    if short_ma > long_ma and rsi < 70:
        raw_signal = "BUY"
    elif short_ma < long_ma and rsi > 30:
        raw_signal = "SELL"
    else:
        raw_signal = "HOLD"

    # ── Map signal + position state to a backtester action ───────────
    if prior_position is None:
        # Flat — consider opening a position
        if raw_signal in ("BUY", "SELL"):
            shares = math.floor(cash / price) if price > 0 else 0
            if raw_signal == "BUY":
                stop_price  = price - _ATR_STOP * atr
                take_profit = price + _ATR_TP   * atr
            else:
                stop_price  = price + _ATR_STOP * atr
                take_profit = price - _ATR_TP   * atr
            return {
                "action":      "ENTER",
                "signal":      raw_signal,
                "shares":      shares,
                "stop_loss":   round(stop_price,  4),
                "take_profit": round(take_profit, 4),
            }
        # HOLD with no position → stay flat
        return {
            "action": "CONTINUE", "signal": "BUY",
            "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
        }

    else:
        # In a position
        if raw_signal == "HOLD" or raw_signal == prior_position:
            # Same direction or undecided — keep holding
            return {
                "action": "CONTINUE", "signal": prior_position,
                "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
            }
        else:
            # Signal flipped — exit cleanly; backtester re-evaluates next bar
            return {
                "action": "EXIT", "signal": prior_position,
                "shares": 0, "stop_loss": 0.0, "take_profit": 0.0,
            }

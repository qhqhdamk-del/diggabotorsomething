"""
daytrader.py
============
Single-file day-trading signal generator using Alpaca market data.

The algorithm combines 7 technical indicators into a weighted composite,
but is **regime-aware** — it detects whether the market is trending or
ranging and adapts its interpretation of momentum indicators accordingly.

In trending markets: momentum indicators confirm the trend.
In ranging markets: momentum indicators flag mean-reversion opportunities.

Hard trend filters block signals that fight a clearly established trend
(e.g. no BUY if price is below the 50-EMA, or if the last 10 bars are
falling, or if ADX > 30 in a downtrend).

Indicators used:
  Trend:      EMA stack (9/21/50), MACD histogram, ADX/DI
  Momentum:   RSI (14, regime-aware)
  Volatility: Bollinger %B (regime-aware)
  Volume:     VWAP, OBV slope

ATR is used for volatility-aware stops and a low-volatility confidence
filter, not as a voting factor.

Usage from another Python file:

    from daytrader import analyze

    result = analyze("AAPL")
    print(result["signal"])     # "BUY", "SELL", or "HOLD"

Setup
-----
1.  pip install alpaca-py pandas numpy
2.  Provide your Alpaca credentials in one of three ways (first match wins):
      a. A text file named API_KEY.txt next to this module or in the
         working directory, with the API key on line 1 and the secret key
         on line 2:
             PKXXXXXXXXXXXXXXXXXX
             your_secret_key_here
      b. configure(api_key="...", secret_key="...") before the first call
      c. ALPACA_API_KEY / ALPACA_SECRET_KEY environment variables

    The API_KEY.txt file is the default — just drop it next to the module
    and you're done.

Data feed
---------
By default this module uses the **IEX feed** (real-time, free with any
Alpaca account, but only ~2% of total US market volume).

If you have an Algo Trader Plus subscription (~$99/mo), you can switch
to the full-market SIP feed:

    analyze("AAPL", feed="sip")
    # or set the default for all calls:
    configure(feed="sip")
"""

from __future__ import annotations
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
from alpaca.data.enums import DataFeed


# ---------------------------------------------------------------------------
# Tuning parameters — edit these to adjust the algorithm's behavior
# ---------------------------------------------------------------------------
# All algorithm thresholds live here so you don't have to hunt for them
# in the code. Defaults are reasonable starting points based on common
# practice, but they are NOT optimized for any specific symbol or
# timeframe. Backtest before changing.

# -- RSI thresholds (regime-aware) ------------------------------------------
# Ranging market: classic Wilder mean-reversion extremes
RSI_OVERSOLD = 30        # below this in a range = strong BUY signal
RSI_OVERBOUGHT = 70      # above this in a range = strong SELL signal

# Trending market: momentum continuation vs. weakness (Constance Brown levels)
# In a healthy uptrend RSI rarely drops below ~40; in a downtrend rarely
# rises above ~60. So 40/60 detect *loss of momentum* rather than extremes.
RSI_TREND_LOW = 40       # RSI below this in an uptrend = warning sign
RSI_TREND_HIGH = 60      # RSI above this in a downtrend = bounce warning

# -- Bollinger %B thresholds ------------------------------------------------
# Ranging market: band touches signal reversal
BB_LOWER_EXTREME = 0.1   # %B below this in a range = BUY (oversold)
BB_UPPER_EXTREME = 0.9   # %B above this in a range = SELL (overbought)
# Trending market: band touches signal continuation
BB_TREND_LOW = 0.2       # %B below this in a downtrend = riding lower band
BB_TREND_HIGH = 0.8      # %B above this in an uptrend = riding upper band

# -- Regime detection thresholds --------------------------------------------
ADX_TRENDING = 25        # ADX above this = market is trending
ADX_STRONG_TREND = 30    # ADX above this triggers the strong-trend veto
ADX_NORMALIZATION = 25   # Range of ADX over which adx-score scales 0→1
ADX_FLOOR = 15           # Below this ADX, score = 0 (no trend signal)

# -- EMA periods (trend stack) ---------------------------------------------
EMA_FAST = 9
EMA_MID = 21
EMA_SLOW = 50            # also used as the "higher-timeframe trend" reference

# -- Higher-timeframe trend filter -----------------------------------------
# How far price must be above/below the slow EMA to count as a real trend
HIGHER_TF_TOLERANCE = 0.002   # 0.2% above/below the 50-EMA

# -- Short-term slope filter -----------------------------------------------
SLOPE_LOOKBACK_BARS = 10      # how many bars to fit the slope over
SLOPE_VETO_THRESHOLD = 0.002  # 0.2% move against signal in 10 bars = veto

# -- Other indicator periods -----------------------------------------------
RSI_PERIOD = 14
ATR_PERIOD = 14
BB_PERIOD = 20
BB_STD = 2.0
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
ADX_PERIOD = 14

# -- Decision thresholds ----------------------------------------------------
MIN_CONFIDENCE = 0.20         # below this, signal is always HOLD (when flat)
MIN_BARS_REQUIRED = 50        # minimum bars needed before analyzing

# -- Volatility filter ------------------------------------------------------
# Only kicks in for truly dead markets. 0.05% per bar means a stock barely
# moving at all over the lookback. Liquid stocks normally show 0.1-0.3%.
# If your symbol's bars routinely show ATR < this fraction of price, the
# market is genuinely too quiet to trade and confidence is dampened.
MIN_ATR_PCT = 0.0005          # 0.05% of price
VOL_DAMPENER_FLOOR = 0.5      # confidence multiplier floor in dead markets

# -- Risk management --------------------------------------------------------
RISK_PER_TRADE = 0.01         # risk this fraction of capital per trade (1%)
REWARD_RISK_RATIO = 2.0       # take-profit is N × stop distance
ATR_STOP_MULTIPLIER = 1.5     # stop is N × ATR away from entry
MAX_POSITION_PCT = 0.25       # never deploy more than this fraction of capital

# -- Factor weights (must sum to 1.0) ---------------------------------------
FACTOR_WEIGHTS = {
    "ema_stack":  0.20,       # trend direction
    "macd":       0.15,       # trend/momentum shifts
    "adx":        0.15,       # trend strength
    "rsi":        0.15,       # momentum (regime-aware)
    "bollinger":  0.10,       # volatility-relative position (regime-aware)
    "vwap":       0.15,       # price vs institutional benchmark
    "obv":        0.10,       # volume flow
}
assert abs(sum(FACTOR_WEIGHTS.values()) - 1.0) < 1e-9, \
    f"weights must sum to 1.0, got {sum(FACTOR_WEIGHTS.values())}"

# -- Short-term reactivity (for exiting existing positions) -----------------
# When already in a position, the algorithm watches the last few bars
# closely and will exit if price moves sharply against the position.
# These thresholds apply ONLY to exit decisions; entries still require
# full multi-indicator confirmation.
SHORT_TERM_BARS = 3              # lookback for "what's price doing right now"
EXIT_MOMENTUM_THRESHOLD = 0.003  # 0.3% adverse move over SHORT_TERM_BARS = exit
HARD_STOP_ATR_MULT = 2.0         # |move| in ATRs that triggers immediate exit
# Weight of the short-term signal when in a position (0..1). Higher = more
# reactive but more churn. 0.5 means the short-term factor and the regular
# composite each get 50% influence.
EXIT_REACTIVITY_WEIGHT = 0.5

# -- Position memory --------------------------------------------------------
# The algorithm persists "what did I last say about each symbol" so it can
# avoid emitting HOLD after a previous BUY (which would leave your bot
# unsure whether to keep holding or sell). Storage file lives next to the
# module by default; override via configure(state_path=...).
DEFAULT_STATE_FILENAME = "daytrader_state.json"

# -- Alpaca credentials -----------------------------------------------------
# By default, credentials are read from a text file with the API key on
# line 1 and the secret key on line 2. The file is looked for next to this
# module (and in the current working directory). Override the path with
# configure(key_file=...).
DEFAULT_KEY_FILENAME = "API_KEY.txt"


# ---------------------------------------------------------------------------
# Client management
# ---------------------------------------------------------------------------

_client: Optional[StockHistoricalDataClient] = None
# Default to IEX. The free Alpaca subscription only includes IEX data;
# SIP requires Algo Trader Plus (~$99/mo). The SDK's "auto" mode has a
# known bug where it sometimes routes free accounts to SIP and fails,
# so we set this explicitly.
_default_feed: str = "iex"


def _read_key_file(key_file: Optional[str] = None) -> tuple[Optional[str], Optional[str]]:
    """Read Alpaca credentials from a text file.

    Format: API key on line 1, secret key on line 2. Blank lines and
    surrounding whitespace are ignored.

    Search order when key_file is None:
      1. API_KEY.txt next to this module
      2. API_KEY.txt in the current working directory

    Returns (api_key, secret_key), or (None, None) if no file found.
    """
    candidates = []
    if key_file is not None:
        candidates.append(Path(key_file))
    else:
        candidates.append(Path(__file__).parent / DEFAULT_KEY_FILENAME)
        candidates.append(Path.cwd() / DEFAULT_KEY_FILENAME)

    for path in candidates:
        if path.exists():
            try:
                lines = [ln.strip() for ln in path.read_text().splitlines()
                         if ln.strip()]
            except OSError as e:
                raise ValueError(f"Could not read key file '{path}': {e}") from e
            if len(lines) < 2:
                raise ValueError(
                    f"Key file '{path}' must have the API key on line 1 "
                    f"and the secret key on line 2 (found {len(lines)} "
                    f"non-empty line(s))."
                )
            return lines[0], lines[1]

    return None, None


def configure(
    api_key: Optional[str] = None,
    secret_key: Optional[str] = None,
    feed: Optional[str] = None,
    key_file: Optional[str] = None,
) -> None:
    """Configure Alpaca credentials and default data feed.

    Credential resolution order (first match wins):
      1. Explicit api_key / secret_key arguments
      2. A text file (API_KEY.txt by default; key on line 1, secret on
         line 2). Pass key_file=... to point at a different path.
      3. ALPACA_API_KEY / ALPACA_SECRET_KEY environment variables

    Parameters
    ----------
    api_key, secret_key : str
        Alpaca credentials. If omitted, read from the key file or env vars.
    feed : "iex" | "sip" | None
        Data feed. Defaults to "iex" (free tier). Pass "sip" only if
        you have an Algo Trader Plus subscription.
    key_file : str
        Path to the credentials text file. Defaults to API_KEY.txt next to
        this module or in the current working directory.
    """
    global _client, _default_feed

    key = api_key
    secret = secret_key

    # 2) Try the key file if either credential is still missing
    if not key or not secret:
        file_key, file_secret = _read_key_file(key_file)
        key = key or file_key
        secret = secret or file_secret

    # 3) Fall back to environment variables
    if not key:
        key = os.environ.get("ALPACA_API_KEY")
    if not secret:
        secret = os.environ.get("ALPACA_SECRET_KEY")

    if not key or not secret:
        raise ValueError(
            f"Alpaca credentials missing. Provide them one of three ways:\n"
            f"  1. configure(api_key=..., secret_key=...)\n"
            f"  2. A '{DEFAULT_KEY_FILENAME}' file (API key on line 1, "
            f"secret key on line 2) next to the module or in the working dir\n"
            f"  3. ALPACA_API_KEY and ALPACA_SECRET_KEY environment variables"
        )

    _client = StockHistoricalDataClient(key, secret)
    if feed is not None:
        _default_feed = feed


def _get_client() -> StockHistoricalDataClient:
    if _client is None:
        configure()
    return _client  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def analyze(
    symbol: str,
    capital: float = 10_000.0,
    bar_minutes: int = 5,
    lookback_days: int = 5,
    feed: Optional[str] = None,
) -> dict:
    """
    Fetch recent bars from Alpaca, run 7 indicators, return a decision.

    The function maintains per-symbol state across calls in a JSON file
    next to this module (override with set_state_path). Once it emits BUY
    or SELL for a symbol, subsequent calls for the same symbol will never
    return HOLD — they return either the same direction (stay in the
    position) or the opposite (close it). This prevents the bot from
    being told "HOLD" after having already entered a position.

    If your bot closes a position externally (manual sale, broker stop
    hit), call reset_state(symbol) so the algorithm starts fresh.

    Returns a dict with:
        symbol, signal ("BUY"|"SELL"|"HOLD"), confidence (0-1),
        entry_price, stop_loss, take_profit, shares, reasoning, timestamp,
        position (the position state going INTO this call: "BUY"|"SELL"|None)
    """
    df = _fetch_bars(symbol, bar_minutes, lookback_days, feed)

    state = _load_state()
    prior = state.get(symbol, {})
    prior_position = prior.get("position")  # "BUY" | "SELL" | None

    decision = _decide(symbol, df, capital, prior_position)

    # Update state: track the new position after this call
    new_signal = decision["signal"]
    if new_signal == "BUY":
        new_position = "BUY"
    elif new_signal == "SELL":
        # SELL closes a long (BUY) position OR opens a short (SELL) position.
        # We treat SELL as "no position" after closing a long, otherwise as
        # opening a short. This matches typical retail bot behavior; if your
        # bot can actually short, change SELL handling here.
        new_position = None if prior_position == "BUY" else "SELL"
    else:  # HOLD
        new_position = prior_position  # unchanged

    state[symbol] = {
        "position": new_position,
        "last_signal": new_signal,
        "last_price": decision["entry_price"],
        "last_timestamp": decision["timestamp"],
    }
    _save_state(state)

    decision["position"] = prior_position
    return decision


# ---------------------------------------------------------------------------
# Alpaca data fetching
# ---------------------------------------------------------------------------

def _resolve_feed(name: Optional[str]) -> DataFeed:
    """Map a string ('iex'|'sip') to the DataFeed enum."""
    chosen = (name or _default_feed or "iex").lower()
    if chosen == "iex":
        return DataFeed.IEX
    if chosen == "sip":
        return DataFeed.SIP
    raise ValueError(f"Unknown feed: {name!r}. Use 'iex' or 'sip'.")


def _fetch_bars(
    symbol: str,
    bar_minutes: int,
    lookback_days: int,
    feed: Optional[str],
) -> pd.DataFrame:
    client = _get_client()
    data_feed = _resolve_feed(feed)

    end = datetime.now(timezone.utc)
    start = end - timedelta(days=lookback_days)
    timeframe = TimeFrame(amount=bar_minutes, unit=TimeFrameUnit.Minute)

    request = StockBarsRequest(
        symbol_or_symbols=symbol,
        timeframe=timeframe,
        start=start,
        end=end,
        feed=data_feed,
    )

    try:
        barset = client.get_stock_bars(request)
    except Exception as e:
        msg = str(e)
        if "subscription does not permit" in msg.lower() or "sip" in msg.lower():
            raise ValueError(
                f"Alpaca rejected the data request: {msg}\n"
                f"Your account does not have SIP access. Either:\n"
                f"  1. Use the free IEX feed by passing feed='iex' (default), or\n"
                f"  2. Upgrade to Algo Trader Plus (~$99/mo) for SIP access."
            ) from e
        raise

    df = barset.df
    if df is None or df.empty:
        raise ValueError(
            f"No bars returned for '{symbol}'. Check the symbol, "
            f"market hours, or try a longer lookback_days."
        )

    if isinstance(df.index, pd.MultiIndex):
        df = df.xs(symbol, level="symbol")

    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC")
    df.index = df.index.tz_convert("America/New_York")

    df = df[["open", "high", "low", "close", "volume"]].dropna()
    if len(df) < MIN_BARS_REQUIRED:
        raise ValueError(
            f"Only {len(df)} bars for '{symbol}'; need >={MIN_BARS_REQUIRED}. "
            f"Try a larger lookback_days or smaller bar_minutes."
        )
    return df


# ---------------------------------------------------------------------------
# Technical indicators
# ---------------------------------------------------------------------------

def _ema(s: pd.Series, period: int) -> pd.Series:
    return s.ewm(span=period, adjust=False).mean()


def _rma(s: pd.Series, period: int) -> pd.Series:
    """Wilder's smoothing (used by RSI, ADX, ATR)."""
    return s.ewm(alpha=1 / period, adjust=False).mean()


def _true_range(df: pd.DataFrame) -> pd.Series:
    high_low = df["high"] - df["low"]
    high_close = (df["high"] - df["close"].shift()).abs()
    low_close = (df["low"] - df["close"].shift()).abs()
    return pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)


def _atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> pd.Series:
    return _rma(_true_range(df), period)


def _rsi(close: pd.Series, period: int = RSI_PERIOD) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = _rma(gain, period)
    avg_loss = _rma(loss, period)
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def _macd(close: pd.Series):
    macd_line = _ema(close, MACD_FAST) - _ema(close, MACD_SLOW)
    signal_line = _ema(macd_line, MACD_SIGNAL)
    return macd_line, signal_line, macd_line - signal_line


def _bollinger(close: pd.Series, period: int = BB_PERIOD, num_std: float = BB_STD):
    mid = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = mid + num_std * std
    lower = mid - num_std * std
    pct_b = (close - lower) / (upper - lower).replace(0, np.nan)
    return upper, mid, lower, pct_b


def _adx(df: pd.DataFrame, period: int = ADX_PERIOD):
    """Returns (adx, plus_di, minus_di)."""
    high, low = df["high"], df["low"]
    up_move = high.diff()
    down_move = -low.diff()

    plus_dm = pd.Series(
        np.where((up_move > down_move) & (up_move > 0), up_move, 0.0),
        index=df.index,
    )
    minus_dm = pd.Series(
        np.where((down_move > up_move) & (down_move > 0), down_move, 0.0),
        index=df.index,
    )

    atr = _rma(_true_range(df), period)
    plus_di = 100 * _rma(plus_dm, period) / atr.replace(0, np.nan)
    minus_di = 100 * _rma(minus_dm, period) / atr.replace(0, np.nan)
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    adx = _rma(dx, period)
    return adx, plus_di, minus_di


def _vwap(df: pd.DataFrame) -> pd.Series:
    """Session-resetting VWAP (resets each US/Eastern trading day)."""
    typical = (df["high"] + df["low"] + df["close"]) / 3
    grouper = pd.Series(df.index.date, index=df.index)
    cum_vol = df["volume"].groupby(grouper).cumsum()
    cum_pv = (typical * df["volume"]).groupby(grouper).cumsum()
    return cum_pv / cum_vol.replace(0, np.nan)


def _obv(df: pd.DataFrame) -> pd.Series:
    direction = np.sign(df["close"].diff()).fillna(0)
    return (direction * df["volume"]).cumsum()


# ---------------------------------------------------------------------------
# Position state — persists across calls so we don't emit HOLD after BUY
# ---------------------------------------------------------------------------


_state_path: Optional[Path] = None


def _get_state_path() -> Path:
    """Return the path to the JSON state file (next to this module by default)."""
    global _state_path
    if _state_path is None:
        _state_path = Path(__file__).parent / DEFAULT_STATE_FILENAME
    return _state_path


def set_state_path(path: str) -> None:
    """Override where the state JSON file is stored."""
    global _state_path
    _state_path = Path(path)


def _load_state() -> dict:
    """Load the per-symbol state dict. Returns {} if no file yet."""
    path = _get_state_path()
    if not path.exists():
        return {}
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def _save_state(state: dict) -> None:
    """Atomically write the state dict to disk."""
    path = _get_state_path()
    tmp = path.with_suffix(".tmp")
    try:
        with open(tmp, "w") as f:
            json.dump(state, f, indent=2)
        tmp.replace(path)
    except OSError:
        pass  # storage failures shouldn't break trading logic


def reset_state(symbol: Optional[str] = None) -> None:
    """Clear state for one symbol, or for all symbols if symbol=None.

    Useful to call from your bot when a position is closed externally
    (e.g. manual sale, stop-loss hit at broker), so the algorithm starts
    fresh on the next call.
    """
    state = _load_state()
    if symbol is None:
        state = {}
    else:
        state.pop(symbol, None)
    _save_state(state)


def get_state(symbol: Optional[str] = None) -> dict:
    """Read current state. Useful for debugging or syncing your bot's view."""
    state = _load_state()
    if symbol is None:
        return state
    return state.get(symbol, {})


# ---------------------------------------------------------------------------
# Short-term reactivity — used only when already in a position
# ---------------------------------------------------------------------------

def _short_term_momentum(df: pd.DataFrame, atr_val: float) -> dict:
    """Measure the last few bars' price action.

    Returns:
        recent_change_pct:   % change over the last SHORT_TERM_BARS bars
        recent_change_atrs:  same change measured in ATR units
        last_bar_direction:  +1 if last bar is green, -1 if red, 0 if doji
        consecutive_against: count of recent bars moving against a hypothetical
                             position (used by callers — see _exit_signal)
    """
    close = df["close"]
    n = min(SHORT_TERM_BARS, len(close) - 1)
    if n < 1:
        return {"recent_change_pct": 0.0, "recent_change_atrs": 0.0,
                "last_bar_direction": 0, "n_bars": 0}

    start = float(close.iloc[-n - 1])
    end = float(close.iloc[-1])
    change_pct = (end - start) / start if start else 0.0
    change_atrs = (end - start) / atr_val if atr_val > 0 else 0.0

    last_open = float(df["open"].iloc[-1])
    last_close = float(close.iloc[-1])
    last_dir = 1 if last_close > last_open else -1 if last_close < last_open else 0

    return {
        "recent_change_pct": change_pct,
        "recent_change_atrs": change_atrs,
        "last_bar_direction": last_dir,
        "n_bars": n,
    }


def _exit_signal(position: str, st: dict) -> Optional[str]:
    """Decide whether short-term price action alone justifies an immediate exit.

    Returns "SELL" if we're long and price is dumping, "BUY" if we're short
    and price is ripping. Returns None if no exit is warranted yet.
    """
    change_pct = st["recent_change_pct"]
    change_atrs = st["recent_change_atrs"]

    # Hard stop: a big adverse move in ATR units, regardless of % size
    if position == "BUY" and change_atrs <= -HARD_STOP_ATR_MULT:
        return "SELL"
    if position == "SELL" and change_atrs >= HARD_STOP_ATR_MULT:
        return "BUY"

    # Soft exit: smaller but consistent adverse move
    if position == "BUY" and change_pct <= -EXIT_MOMENTUM_THRESHOLD:
        return "SELL"
    if position == "SELL" and change_pct >= EXIT_MOMENTUM_THRESHOLD:
        return "BUY"

    return None


# ---------------------------------------------------------------------------
# Factor scorers — each returns a value in [-1, +1]
# +1 = strong bullish, -1 = strong bearish, 0 = neutral
# ---------------------------------------------------------------------------

def _score_ema_stack(close: pd.Series) -> float:
    e_fast = _ema(close, EMA_FAST).iloc[-1]
    e_mid = _ema(close, EMA_MID).iloc[-1]
    e_slow = _ema(close, EMA_SLOW).iloc[-1]
    if e_fast > e_mid > e_slow:
        return 1.0
    if e_fast < e_mid < e_slow:
        return -1.0
    return 0.4 * float(np.sign(e_fast - e_mid))


def _score_macd(close: pd.Series) -> float:
    _, _, hist = _macd(close)
    h_now = float(hist.iloc[-1]) if not pd.isna(hist.iloc[-1]) else 0.0
    h_prev = float(hist.iloc[-2]) if not pd.isna(hist.iloc[-2]) else 0.0
    price = float(close.iloc[-1])
    if h_now > 0 and h_prev <= 0:
        return 1.0
    if h_now < 0 and h_prev >= 0:
        return -1.0
    return float(np.clip(h_now / (price * 0.005), -0.6, 0.6))


def _score_adx(df: pd.DataFrame) -> float:
    """ADX-weighted directional bias.

    DI+ > DI- => bullish, magnitude scales with ADX strength.
    Score is zero when ADX is below ADX_FLOOR; reaches max when ADX hits
    ADX_FLOOR + ADX_NORMALIZATION.
    """
    adx, plus_di, minus_di = _adx(df)
    a = float(adx.iloc[-1]) if not pd.isna(adx.iloc[-1]) else 0.0
    pd_ = float(plus_di.iloc[-1]) if not pd.isna(plus_di.iloc[-1]) else 0.0
    md = float(minus_di.iloc[-1]) if not pd.isna(minus_di.iloc[-1]) else 0.0
    if pd_ + md == 0:
        return 0.0
    direction = (pd_ - md) / (pd_ + md)
    strength = float(np.clip((a - ADX_FLOOR) / ADX_NORMALIZATION, 0, 1))
    return direction * strength


def _market_regime(df: pd.DataFrame) -> dict:
    """Detect whether the market is trending or ranging, and which direction.

    Returns a dict:
        regime:      "trending_up" | "trending_down" | "ranging"
        adx_value:   current ADX reading
        slope_pct:   short-term price slope (% over last SLOPE_LOOKBACK_BARS)
        higher_tf:   coarse direction vs. EMA_SLOW: +1/0/-1
    """
    adx, plus_di, minus_di = _adx(df)
    a = float(adx.iloc[-1]) if not pd.isna(adx.iloc[-1]) else 0.0
    pd_ = float(plus_di.iloc[-1]) if not pd.isna(plus_di.iloc[-1]) else 0.0
    md = float(minus_di.iloc[-1]) if not pd.isna(minus_di.iloc[-1]) else 0.0

    close = df["close"]
    # Slope of last N bars (linear fit, normalized to %)
    n = min(SLOPE_LOOKBACK_BARS, len(close) - 1)
    recent = close.iloc[-n:]
    x = np.arange(len(recent))
    slope_per_bar = np.polyfit(x, recent.values, 1)[0]
    slope_pct = (slope_per_bar * n) / float(recent.iloc[0]) if recent.iloc[0] else 0.0

    # Higher-timeframe direction: where is price relative to the slow EMA?
    ema_slow = _ema(close, EMA_SLOW).iloc[-1]
    higher_tf = 1 if close.iloc[-1] > ema_slow * (1 + HIGHER_TF_TOLERANCE) else \
                -1 if close.iloc[-1] < ema_slow * (1 - HIGHER_TF_TOLERANCE) else 0

    # Classify regime
    if a >= ADX_TRENDING and pd_ > md:
        regime = "trending_up"
    elif a >= ADX_TRENDING and md > pd_:
        regime = "trending_down"
    else:
        regime = "ranging"

    return {
        "regime": regime,
        "adx_value": a,
        "slope_pct": slope_pct,
        "higher_tf": higher_tf,
    }


def _score_rsi(close: pd.Series, regime: str) -> float:
    """Regime-aware RSI.

    In trending markets: RSI is a momentum/continuation signal
        - High RSI (>50) in uptrend = bullish momentum (BUY)
        - Low RSI (<50) in downtrend = bearish momentum (SELL)
        - "Oversold" in a downtrend is NOT a buy signal; the trend keeps going.

    In ranging markets: RSI is mean-reversion
        - <30 = bullish reversal
        - >70 = bearish reversal
    """
    rsi = _rsi(close, RSI_PERIOD)
    r = float(rsi.iloc[-1]) if not pd.isna(rsi.iloc[-1]) else 50.0

    if regime == "trending_up":
        # In uptrend: high RSI = continuation, low RSI = weakness
        if r > RSI_TREND_HIGH:
            return 0.8
        if r > 50:
            return 0.4
        if r < RSI_TREND_LOW:
            return -0.6   # losing momentum
        return 0.0
    if regime == "trending_down":
        # In downtrend: low RSI = continuation, high RSI = bounce/weakness
        if r < RSI_TREND_LOW:
            return -0.8
        if r < 50:
            return -0.4
        if r > RSI_TREND_HIGH:
            return 0.6    # losing downward momentum
        return 0.0
    # Ranging: classic mean-reversion (Wilder thresholds)
    if r < RSI_OVERSOLD:
        return 1.0
    if r > RSI_OVERBOUGHT:
        return -1.0
    if 50 < r < 65:
        return 0.3
    if 35 < r < 50:
        return -0.3
    return 0.0


def _score_bollinger(close: pd.Series, regime: str) -> float:
    """Regime-aware Bollinger %B.

    In trending markets: band touches are continuation signals, not reversals
        - Riding the upper band in an uptrend = strong momentum (BUY)
        - Riding the lower band in a downtrend = strong weakness (SELL)

    In ranging markets: band touches are reversal signals (classic usage).
    """
    _, _, _, pct_b = _bollinger(close)
    pb = pct_b.iloc[-1]
    if pd.isna(pb):
        return 0.0
    pb = float(pb)

    if regime == "trending_up":
        if pb > BB_TREND_HIGH:
            return 0.7    # riding the upper band, bullish
        if pb < 0.3:
            return -0.4   # pulling back in an uptrend, caution
        return 0.2
    if regime == "trending_down":
        if pb < BB_TREND_LOW:
            return -0.7   # riding the lower band, bearish
        if pb > 0.7:
            return 0.4    # bouncing in a downtrend, caution
        return -0.2
    # Ranging: classic mean-reversion (extreme band touches)
    if pb < BB_LOWER_EXTREME:
        return 0.8
    if pb > BB_UPPER_EXTREME:
        return -0.8
    return 0.5 - pb


def _score_vwap(df: pd.DataFrame, atr_val: float) -> float:
    price = float(df["close"].iloc[-1])
    vwap = float(_vwap(df).iloc[-1])
    atr_safe = atr_val if atr_val > 0 else price * 0.01
    return float(np.clip((price - vwap) / atr_safe, -1, 1)) * 0.7


def _score_obv(df: pd.DataFrame) -> float:
    obv_slope = _obv(df).diff(5)
    avg_vol = float(df["volume"].rolling(20).mean().iloc[-1])
    if avg_vol <= 0 or pd.isna(obv_slope.iloc[-1]):
        return 0.0
    return float(np.tanh(obv_slope.iloc[-1] / (avg_vol * 5)))


# ---------------------------------------------------------------------------
# Decision logic
# ---------------------------------------------------------------------------
# Note: FACTOR_WEIGHTS, MIN_CONFIDENCE, and all other thresholds are
# defined at the top of this file in the "Tuning parameters" section.


def _decide(
    symbol: str,
    df: pd.DataFrame,
    capital: float,
    prior_position: Optional[str] = None,
) -> dict:
    """
    Core decision function. Position-aware:
      - prior_position=None    -> "no position": can return BUY / SELL / HOLD
      - prior_position="BUY"   -> "long": can return BUY (continue) or SELL (exit),
                                  never HOLD
      - prior_position="SELL"  -> "short": can return SELL (continue) or BUY (cover),
                                  never HOLD
    """
    close = df["close"]
    price = float(close.iloc[-1])

    atr = _atr(df)
    atr_val = float(atr.iloc[-1]) if not pd.isna(atr.iloc[-1]) else price * 0.01

    # Detect market regime first — several scorers need it
    regime_info = _market_regime(df)
    regime = regime_info["regime"]
    higher_tf = regime_info["higher_tf"]
    slope_pct = regime_info["slope_pct"]

    scores = {
        "ema_stack": _score_ema_stack(close),
        "macd":      _score_macd(close),
        "adx":       _score_adx(df),
        "rsi":       _score_rsi(close, regime),
        "bollinger": _score_bollinger(close, regime),
        "vwap":      _score_vwap(df, atr_val),
        "obv":       _score_obv(df),
    }

    composite = sum(scores[k] * FACTOR_WEIGHTS[k] for k in FACTOR_WEIGHTS)

    # Short-term momentum: blend in last few bars for reactivity
    st = _short_term_momentum(df, atr_val)
    # Short-term score in [-1, +1], scaled by how big the move is vs ATR
    st_score = float(np.clip(st["recent_change_atrs"] / 2.0, -1.0, 1.0))

    # When already in a position, blend short-term momentum into the composite
    # so we exit faster. When flat, use composite alone (slow, careful entries).
    if prior_position is not None:
        blended = (1 - EXIT_REACTIVITY_WEIGHT) * composite \
                  + EXIT_REACTIVITY_WEIGHT * st_score
    else:
        blended = composite

    # Low-volatility filter
    atr_pct = atr_val / price if price > 0 else 0
    vol_dampener = float(np.clip(atr_pct / MIN_ATR_PCT, VOL_DAMPENER_FLOOR, 1.0))
    confidence = min(abs(blended) * vol_dampener, 1.0)

    # --- Preliminary signal based on the blended composite ---
    if confidence < MIN_CONFIDENCE:
        prelim_signal = "HOLD"
    elif blended > 0:
        prelim_signal = "BUY"
    else:
        prelim_signal = "SELL"

    # === HARD TREND-VETO FILTERS (entries only) ==========================
    # These prevent fighting an established trend on NEW entries. They do
    # NOT block exits — if we're long and need to get out, we get out.
    veto_reason = None
    signal = prelim_signal

    if prior_position is None:  # flat — entry filters apply
        if signal == "BUY" and higher_tf < 0:
            signal = "HOLD"; veto_reason = f"below_{EMA_SLOW}ema"
        elif signal == "SELL" and higher_tf > 0:
            signal = "HOLD"; veto_reason = f"above_{EMA_SLOW}ema"
        elif signal == "BUY" and slope_pct < -SLOPE_VETO_THRESHOLD:
            signal = "HOLD"; veto_reason = "negative_short_slope"
        elif signal == "SELL" and slope_pct > SLOPE_VETO_THRESHOLD:
            signal = "HOLD"; veto_reason = "positive_short_slope"
        elif signal == "BUY" and regime == "trending_down" \
                and regime_info["adx_value"] > ADX_STRONG_TREND:
            signal = "HOLD"; veto_reason = "strong_downtrend"
        elif signal == "SELL" and regime == "trending_up" \
                and regime_info["adx_value"] > ADX_STRONG_TREND:
            signal = "HOLD"; veto_reason = "strong_uptrend"
    # =====================================================================

    # === EXIT OVERRIDE: react to sharp adverse short-term moves ===========
    # If we're in a position and the last few bars are moving hard against
    # us, exit *now* even if the slower indicators haven't flipped yet.
    # This is the "go with the market" behavior for risk management.
    exit_override = None
    if prior_position is not None:
        exit_override = _exit_signal(prior_position, st)
        if exit_override is not None:
            signal = exit_override
            veto_reason = "short_term_exit"

    # === POSITION-CONSISTENCY RULE ========================================
    # When already in a position, never emit HOLD. Either continue the
    # position (same direction as prior) or close it (opposite direction).
    if prior_position == "BUY" and signal == "HOLD":
        signal = "BUY"
        veto_reason = veto_reason or "continue_long"
    elif prior_position == "SELL" and signal == "HOLD":
        signal = "SELL"
        veto_reason = veto_reason or "continue_short"
    # =====================================================================

    # --- Risk management ------------------------------------------------
    direction = 1 if signal == "BUY" else -1 if signal == "SELL" else 0
    stop_distance = ATR_STOP_MULTIPLIER * atr_val
    stop_loss = price - direction * stop_distance
    take_profit = price + direction * stop_distance * REWARD_RISK_RATIO

    # Position sizing is only meaningful when we're entering a new position.
    # When we already have a position (signal continues), shares=0 so your
    # bot doesn't accidentally add more on every call.
    is_entry = (prior_position is None and signal in ("BUY", "SELL"))
    if is_entry and stop_distance > 0:
        dollar_risk = capital * RISK_PER_TRADE
        shares = int(dollar_risk / stop_distance)
        max_shares = int((capital * MAX_POSITION_PCT) / price) if price > 0 else 0
        shares = min(shares, max_shares)
    else:
        shares = 0

    try:
        timestamp = df.index[-1].isoformat()
    except AttributeError:
        timestamp = str(df.index[-1])

    # Tag the action so your bot knows whether this is an entry, exit, or hold
    if is_entry:
        action = "ENTER"
    elif prior_position is not None and signal != prior_position:
        action = "EXIT"
    elif prior_position is not None and signal == prior_position:
        action = "CONTINUE"
    else:
        action = "WAIT"

    return {
        "symbol": symbol,
        "signal": signal,
        "action": action,            # ENTER | EXIT | CONTINUE | WAIT
        "confidence": round(confidence, 4),
        "entry_price": round(price, 4),
        "stop_loss": round(stop_loss, 4),
        "take_profit": round(take_profit, 4),
        "shares": shares,
        "reasoning": {k: round(v, 4) for k, v in scores.items()}
                     | {"composite": round(composite, 4),
                        "blended": round(blended, 4),
                        "short_term_atrs": round(st["recent_change_atrs"], 3),
                        "short_term_pct": round(st["recent_change_pct"], 5),
                        "regime": regime,
                        "adx_value": round(regime_info["adx_value"], 2),
                        "slope_pct_10bar": round(slope_pct, 5),
                        "above_50ema": higher_tf,
                        "atr_pct": round(atr_pct, 5),
                        "vol_dampener": round(vol_dampener, 3),
                        "veto": veto_reason,
                        "exit_override": exit_override},
        "timestamp": timestamp,
    }


# ---------------------------------------------------------------------------
# CLI / quick test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    sym = sys.argv[1] if len(sys.argv) > 1 else "AAPL"
    try:
        result = analyze(sym)
        for k, v in result.items():
            print(f"{k:>14}: {v}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
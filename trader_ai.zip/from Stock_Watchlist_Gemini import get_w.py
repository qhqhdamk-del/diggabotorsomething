from Stock_Watchlist_Gemini import get_watchlist

watchlist = get_watchlist()

for stock in watchlist:
    print(stock["symbol"], stock["risk"])

# Get just the ticker symbols
symbols = [stock["symbol"] for stock in watchlist]

# Filter to only low-risk picks
safe_picks = [s for s in watchlist if s["risk"] == "LOW"]

# Access a specific stock
first = watchlist[0]
print(first["company"], "—", first["rationale"])
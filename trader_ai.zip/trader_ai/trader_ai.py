"""
=============================================================================
  TraderAI — Automated Trading Module
  Works alongside trading_bot.py (shares the same API_KEY.txt)
=============================================================================

HOW TO RUN:
    python trader_ai.py

WHAT IT DOES:
    1. Loads API keys from API_KEY.txt (same file used by trading_bot.py).
       If the file doesn't exist it will prompt you once and save it.
    2. Asks you for a dollar amount to invest per trade.
    3. Fetches a watchlist of 5 stocks (refreshed every 60 minutes).
    4. Every 15 seconds, runs both trading algorithms on each stock and
       decides whether to BUY, SELL, or HOLD based on the rules below.

PRICE MODES (chosen at startup):
    Market  — orders fill immediately at the current market price.
    AI Price — the complex algorithm picks the entry price (limit order)
               plus automatic stop-loss and take-profit levels.
               Orders only fill if the market reaches the algo's target price.

DECISION RULES:
    Opening a position (currently own 0 shares):
        LOW risk    → complex algorithm alone decides
        MEDIUM/HIGH → both algorithms must agree

    Closing / reversing a position (currently own shares):
        LOW risk    → both algorithms must agree
        MEDIUM/HIGH → complex algorithm alone decides

SHORT-SELLING:
    When a SELL signal fires and we already hold shares of a stock,
    TraderAI does NOT just sell back to zero. It sells the shares we
    hold PLUS an additional short position sized by the complex
    algorithm. This means we profit even when the stock falls.

    Example: we own +5 AAPL, complex says SELL 10 shares.
             TraderAI sells 15 shares → position becomes -10.

AMOUNT PER TRADE:
    The user sets a dollar budget. The number of shares for each trade
    is: floor(amount_per_trade / current_price), capped at the complex
    algorithm's recommendation.

=============================================================================
"""

import os
import sys
import time
import math
import threading
from datetime import datetime

# ---------------------------------------------------------------------------
#  External algorithm modules supplied by the user
# ---------------------------------------------------------------------------
from Stock_Watchlist_Gemini import get_watchlist                # type: ignore
from Action_Algorithm_Simple import TradingAlgo                 # type: ignore
from Action_Algorithm_Complex import analyze as complex_analyze  # type: ignore
import trade_backtester                                          # post-trade backtest runner

# ---------------------------------------------------------------------------
#  Alpaca imports  (same package used in trading_bot.py)
# ---------------------------------------------------------------------------
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, TakeProfitRequest, StopLossRequest
from alpaca.trading.enums import OrderSide, TimeInForce, OrderClass

# =============================================================================
#  CONFIGURATION
# =============================================================================

# Name of the API-key file (must live in the same folder as this script)
API_KEY_FILE = "API_KEY.txt"

# Set to True only when you want to trade with REAL money
LIVE_TRADING = False

# How often (seconds) to run the algorithms on each stock
SCAN_INTERVAL = 15

# How often (seconds) to refresh the watchlist  (60 min = 3600 s)
WATCHLIST_REFRESH_INTERVAL = 3600

# =============================================================================
#  SHARED STATE  (written by background threads, read by the main loop)
# =============================================================================

# List of dicts: [{"symbol": ..., "company": ..., "risk": ...}, ...]
_watchlist: list[dict] = []
_watchlist_lock = threading.Lock()

# Signals from the last scan cycle, keyed by symbol
# { "AAPL": {"simple": "BUY", "complex": "BUY", "price": 213.4, "confidence": 0.82}, ... }
_last_signals: dict[str, dict] = {}
_signals_lock = threading.Lock()

# The last signal that was actually *executed* per symbol.
# If the new final signal matches this, we skip placing an order (no duplicate trades).
# { "AAPL": "BUY", "NVDA": "SELL", ... }
_last_executed_signal: dict[str, str] = {}
_executed_lock = threading.Lock()

# Set to True to ask all threads to stop cleanly
_shutdown = threading.Event()

# =============================================================================
#  API-KEY LOADING  (identical logic to trading_bot.py)
# =============================================================================

def load_api_keys() -> tuple[str, str]:
    """
    Load API key and secret from API_KEY.txt if it exists,
    otherwise prompt the user and save the file automatically.
    """
    script_dir    = os.path.dirname(os.path.abspath(__file__))
    key_file_path = os.path.join(script_dir, API_KEY_FILE)

    if os.path.exists(key_file_path):
        print(f"[INFO] Found {API_KEY_FILE} — loading API keys from file.")
        try:
            with open(key_file_path, "r") as f:
                lines = [line.strip() for line in f if line.strip()]
            if len(lines) < 2:
                print(f"[ERROR] {API_KEY_FILE} must have two lines: API Key ID then Secret Key.")
                raise SystemExit(1)
            api_key, secret_key = lines[0], lines[1]
            if not (api_key.startswith("PK") or api_key.startswith("AK")):
                print("[WARNING] API key doesn't start with 'PK'/'AK' — double-check it.")
            print("[INFO] API keys loaded.")
            return api_key, secret_key
        except OSError as e:
            print(f"[ERROR] Could not read {API_KEY_FILE}: {e}")
            raise SystemExit(1)

    else:
        print(f"[INFO] {API_KEY_FILE} not found — please enter your Alpaca API keys.")
        print("       They will be saved automatically so you won't be asked again.\n")

        while True:
            api_key = input("  Enter your API Key ID : ").strip()
            if api_key:
                break
            print("  [ERROR] API Key ID cannot be empty.")

        while True:
            secret_key = input("  Enter your Secret Key : ").strip()
            if secret_key:
                break
            print("  [ERROR] Secret Key cannot be empty.")

        try:
            with open(key_file_path, "w") as f:
                f.write(f"{api_key}\n{secret_key}\n")
            print(f"\n[INFO] Keys saved to {key_file_path}")
            print("[INFO] Keep this file private and out of version control.\n")
        except OSError as e:
            print(f"[WARNING] Could not save keys: {e}")

        return api_key, secret_key


# =============================================================================
#  ALPACA CLIENT
# =============================================================================

def create_client(api_key: str, secret_key: str) -> TradingClient:
    """Create and return an authenticated Alpaca TradingClient."""
    paper_mode = not LIVE_TRADING
    mode_label = "LIVE" if LIVE_TRADING else "PAPER"
    print(f"[INFO] Connecting to Alpaca ({mode_label} mode)...")
    return TradingClient(api_key=api_key, secret_key=secret_key, paper=paper_mode)


# =============================================================================
#  POSITION HELPERS
# =============================================================================

def get_position_qty(client: TradingClient, symbol: str) -> float:
    """
    Return the number of shares we currently hold for a given symbol.
    Positive = long, negative = short, 0 = no position.
    """
    try:
        position = client.get_open_position(symbol)
        return float(position.qty)
    except Exception:
        # Alpaca raises an exception (404) when there is no open position
        return 0.0


def get_current_price(complex_result: dict) -> float:
    """Extract the entry price from the complex algorithm's result dict."""
    return float(complex_result.get("entry_price", 0.0))


# =============================================================================
#  LIQUIDATION
# =============================================================================

def liquidate_all_positions(client: TradingClient) -> None:
    """
    Close every open position at market price before loading a new watchlist.
    This protects us from holding stocks that are no longer being monitored.

    Steps:
      1. Cancel all pending orders (so they don't interfere with closing).
      2. Send a market close for every open position.
      3. Wait until all positions are confirmed gone (poll every 3 seconds).
    """
    try:
        positions = client.get_all_positions()
    except Exception as e:
        print(f"[LIQUIDATE] Could not fetch positions: {e}")
        return

    if not positions:
        print("[LIQUIDATE] No open positions to close.")
        return

    symbols = [p.symbol for p in positions]
    print(f"[LIQUIDATE] Closing {len(positions)} position(s): {symbols}")

    try:
        # cancel_orders=True also cancels any open limit/bracket orders first
        client.close_all_positions(cancel_orders=True)
    except Exception as e:
        print(f"[LIQUIDATE] close_all_positions failed: {e}")
        return

    # Poll until Alpaca confirms all positions are gone (max 60 seconds)
    for elapsed in range(0, 61, 3):
        time.sleep(3)
        try:
            remaining = client.get_all_positions()
        except Exception:
            remaining = []
        if not remaining:
            print(f"[LIQUIDATE] All positions closed after {elapsed + 3}s.")

            # Clear last-executed signals so fresh trades can open on the new watchlist
            with _executed_lock:
                _last_executed_signal.clear()
            return
        print(f"[LIQUIDATE] Waiting for {len(remaining)} position(s) to settle... ({elapsed + 3}s)")

    print("[LIQUIDATE] WARNING: Some positions may still be open after 60s. "
          "Check your Alpaca dashboard.")


# =============================================================================
#  ORDER EXECUTION
# =============================================================================

def place_order(
    client: TradingClient,
    symbol: str,
    qty: float,
    side: OrderSide,
    price_mode: str,
    entry_price: float = 0.0,
    stop_loss: float   = 0.0,
    take_profit: float = 0.0,
    regime: str        = "unknown",
    adx_value: float   = 0.0,
) -> None:
    """
    Submit an order for `qty` shares of `symbol`.

    Parameters
    ----------
    client      : authenticated Alpaca client
    symbol      : stock ticker
    qty         : number of shares (will be floored to a whole number)
    side        : OrderSide.BUY or OrderSide.SELL
    price_mode  : "market"  → plain market order
                  "ai"      → limit order at entry_price with bracket
                              stop-loss and take-profit from the complex algo
    entry_price : limit price for AI mode (ignored in market mode)
    stop_loss   : raw stop price from the algo (AI mode only)
    take_profit : raw take-profit price from the algo (AI mode only)
    regime      : market regime from reasoning ("trending_up", "trending_down", "ranging")
    adx_value   : raw ADX reading from reasoning — measures trend strength
                  ADX ≥ 25 → strong trend; ADX < 20 → weak/choppy market

    Bracket adjustment logic (AI mode only):
        Strong trend  (ADX ≥ 25 AND regime is trending):
            Use algo's stop and take-profit as-is. The trend gives room to run.
        Weak / ranging (ADX < 20 OR regime == "ranging"):
            Widen stop by 20%  — choppy markets trigger tight stops on noise.
            Tighten TP  by 20% — take gains sooner; ranging markets mean-revert.
    """
    qty = math.floor(qty)
    if qty == 0:
        print(f"  {symbol:<6}  SKIP    Rounded qty=0 — budget too small for one share.")
        return False

    try:
        if price_mode == "ai" and entry_price > 0 and stop_loss > 0 and take_profit > 0:
            is_trending = regime in ("trending_up", "trending_down")
            is_strong   = adx_value >= 25 and is_trending

            stop_dist = abs(entry_price - stop_loss)
            tp_dist   = abs(entry_price - take_profit)

            if not is_strong:
                stop_dist *= 1.20
                tp_dist   *= 0.80
                adj_label  = f"adj(ADX={adx_value:.1f},{regime})"
            else:
                adj_label  = f"raw(ADX={adx_value:.1f},{regime})"

            if side == OrderSide.BUY:
                adj_stop = entry_price - stop_dist
                adj_tp   = entry_price + tp_dist
            else:
                adj_stop = entry_price + stop_dist
                adj_tp   = entry_price - tp_dist

            request = LimitOrderRequest(
                symbol=symbol,
                qty=qty,
                side=side,
                limit_price=round(entry_price, 2),
                time_in_force=TimeInForce.DAY,
                order_class=OrderClass.BRACKET,
                take_profit=TakeProfitRequest(limit_price=round(adj_tp,   2)),
                stop_loss=StopLossRequest(stop_price=round(adj_stop, 2)),
            )
            order = client.submit_order(request)
            print(f"  {symbol:<6}  ORDER   {side.value.upper()} {qty} shares  "
                  f"entry=${entry_price:.2f}  sl=${adj_stop:.2f}  tp=${adj_tp:.2f}  "
                  f"{adj_label}  id={str(order.id)[:8]}")

        else:
            request = MarketOrderRequest(
                symbol=symbol,
                qty=qty,
                side=side,
                time_in_force=TimeInForce.DAY,
            )
            order = client.submit_order(request)
            print(f"  {symbol:<6}  ORDER   {side.value.upper()} {qty} shares  "
                  f"market price  id={str(order.id)[:8]}")

        return True   # order submitted successfully

    except Exception as e:
        print(f"  {symbol:<6}  ERROR   Order failed: {e}")
        return False  # order was not submitted


# =============================================================================
#  CORE DECISION LOGIC
# =============================================================================

def decide_and_trade(
    client: TradingClient,
    stock: dict,
    amount_per_trade: float,
    price_mode: str,
    use_simple: bool,
) -> None:
    """
    Run the algorithm(s) for one stock, apply the decision rules,
    and place an order only when the signal has changed since the last trade.

    Parameters
    ----------
    client           : authenticated Alpaca client
    stock            : dict with keys "symbol", "company", "risk"
    amount_per_trade : maximum dollar amount to invest per trade
    price_mode       : "market" or "ai" (see place_order for details)
    use_simple       : if False the simple algorithm is skipped entirely and
                       the complex algorithm alone decides for every stock
    """
    symbol = stock["symbol"]
    risk   = stock["risk"].upper()   # "LOW", "MEDIUM", or "HIGH"

    # ------------------------------------------------------------------
    # Step 1 — Run the algorithm(s)
    # ------------------------------------------------------------------
    simple_signal = None   # stays None when use_simple is False

    if use_simple:
        try:
            simple_result = TradingAlgo(symbol).analyze()
            simple_signal = simple_result["signal"].upper()    # "BUY" / "SELL" / "HOLD"
        except Exception as e:
            print(f"  {symbol:<6}  ERROR   Simple algo failed: {e}")
            return

    try:
        complex_result   = complex_analyze(symbol, feed="iex")
        complex_signal   = complex_result["signal"].upper()  # "BUY" / "SELL" / "HOLD"
        algo_entry       = float(complex_result.get("entry_price", 0.0))
        algo_stop_loss   = float(complex_result.get("stop_loss",   0.0))
        algo_take_profit = float(complex_result.get("take_profit", 0.0))

        # ── New reasoning fields ──────────────────────────────────────
        reasoning     = complex_result.get("reasoning", {})
        regime        = reasoning.get("regime",          "unknown")  # trending_up/down/ranging
        adx_value     = float(reasoning.get("adx_value",       0.0))  # raw ADX reading
        slope_pct     = float(reasoning.get("slope_pct_10bar", 0.0))  # short-term price slope
        above_50ema   = int(reasoning.get("above_50ema",         0))  # +1 / 0 / -1
        veto          = reasoning.get("veto",               None)    # None or reason string
    except Exception as e:
        print(f"  {symbol:<6}  ERROR   Complex algo failed: {e}")
        return

    price = get_current_price(complex_result)

    # Store everything so the status display can show it
    with _signals_lock:
        _last_signals[symbol] = {
            "simple":     simple_signal,
            "complex":    complex_signal,
            "price":      price,
            "confidence": complex_result.get("confidence", 0),
            "regime":     regime,
            "adx":        adx_value,
            "slope_pct":  slope_pct,
            "above_50ema":above_50ema,
            "veto":       veto,
        }

    # ------------------------------------------------------------------
    # Step 2 — Veto check (hardest gate — algo forced HOLD internally)
    # ------------------------------------------------------------------
    #
    #  The complex algorithm sets veto to a reason string when it has
    #  overridden a raw signal to HOLD (e.g. "ADX too low", "conflicting
    #  indicators"). If veto is present we must respect it and not trade,
    #  regardless of what any other rule says.
    #
    if veto is not None:
        print(f"  {symbol:<6}  HOLD    VETOED: {veto}  "
              f"(regime={regime}, ADX={adx_value:.1f})")
        return

    # ------------------------------------------------------------------
    # Step 3 — Determine our current position
    # ------------------------------------------------------------------
    current_qty  = get_position_qty(client, symbol)
    has_position = (current_qty != 0.0)

    # ------------------------------------------------------------------
    # Step 4 — Apply decision rules to pick a final signal
    # ------------------------------------------------------------------
    #
    #  When use_simple is True the simple algo acts as a cross-check:
    #    Opening LOW risk    → complex alone decides
    #    Opening MEDIUM/HIGH → both must agree
    #    Closing LOW risk    → both must agree
    #    Closing MEDIUM/HIGH → complex alone decides
    #
    #  When use_simple is False the complex algo decides for every case,
    #  regardless of risk level — equivalent to treating every stock as
    #  "complex alone" for both opening and closing.
    #
    final_signal: str | None = None

    if not use_simple:
        # Complex algorithm decides alone for all risk levels
        if complex_signal in ("BUY", "SELL"):
            final_signal = complex_signal
    elif not has_position:
        if risk == "LOW":
            if complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal
        else:
            if simple_signal == complex_signal and complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal
    else:
        if risk == "LOW":
            if simple_signal == complex_signal and complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal
        else:
            if complex_signal in ("BUY", "SELL"):
                final_signal = complex_signal

    if final_signal is None:
        final_signal = "HOLD"

    # ------------------------------------------------------------------
    # Step 5 — Regime + higher-timeframe alignment gate
    # ------------------------------------------------------------------
    #
    #  Regime alignment:
    #    BUY  into a trending_down regime → fighting the trend → HOLD
    #    SELL into a trending_up   regime → fighting the trend → HOLD
    #
    #  Higher-timeframe (50 EMA) alignment:
    #    BUY  with above_50ema == -1 → HTF is bearish → HOLD
    #    SELL with above_50ema == +1 → HTF is bullish → HOLD
    #
    regime_block = (
        (final_signal == "BUY"  and regime == "trending_down") or
        (final_signal == "SELL" and regime == "trending_up")
    )
    ema_block = (
        (final_signal == "BUY"  and above_50ema == -1) or
        (final_signal == "SELL" and above_50ema == +1)
    )

    if regime_block:
        print(f"  {symbol:<6}  HOLD    regime conflict: {final_signal} vs {regime}  "
              f"ADX={adx_value:.1f}  slope={slope_pct:+.2f}%")
        return

    if ema_block:
        print(f"  {symbol:<6}  HOLD    50EMA conflict: {final_signal} vs "
              f"above_50ema={above_50ema:+d}  regime={regime}")
        return

    # ------------------------------------------------------------------
    # Step 6 — Skip if signal unchanged since last execution
    # ------------------------------------------------------------------
    with _executed_lock:
        prev_signal = _last_executed_signal.get(symbol)

    if final_signal == "HOLD" or final_signal == prev_signal:
        reason      = "no change" if final_signal == prev_signal else "algo says hold"
        simple_part = f"simple={simple_signal:<4}  " if use_simple else ""
        print(f"  {symbol:<6}  HOLD    "
              f"{simple_part}complex={complex_signal:<4}  "
              f"regime={regime:<12}  ADX={adx_value:>5.1f}  "
              f"pos={current_qty:>+6.0f}  price=${price:>8.2f}  ({reason})")
        return

    # ------------------------------------------------------------------
    # Step 7 — Calculate order size from budget
    # ------------------------------------------------------------------
    if price <= 0:
        print(f"  {symbol:<6}  SKIP    Could not determine price.")
        return

    trade_shares = math.floor(amount_per_trade / price)

    if trade_shares <= 0:
        print(f"  {symbol:<6}  SKIP    Budget too small for 1 share at ${price:.2f}.")
        return

    # ------------------------------------------------------------------
    # Step 8 — Derive order quantity via target-position math
    # ------------------------------------------------------------------
    #
    #  BUY  signal → target = +trade_shares  (long)
    #  SELL signal → target = -trade_shares  (short)
    #
    #  order_qty = target − current_qty
    #  Positive → need to BUY;  Negative → need to SELL.
    #
    #  Example — own +5, SELL fires, trade_shares=9:
    #    target    = -9
    #    order_qty = -9 − (+5) = -14  →  SELL 14 shares
    #    new pos   = -9  (profits if price falls)
    #
    target_qty = trade_shares if final_signal == "BUY" else -trade_shares
    order_qty  = target_qty - current_qty

    if order_qty == 0:
        print(f"  {symbol:<6}  HOLD    Already at target position ({current_qty:+.0f}).")
        return

    order_side = OrderSide.BUY if order_qty > 0 else OrderSide.SELL

    simple_part = f"simple={simple_signal:<4}  " if use_simple else ""
    print(f"  {symbol:<6}  {final_signal:<6}  "
          f"{simple_part}complex={complex_signal:<4}  "
          f"regime={regime:<12}  ADX={adx_value:>5.1f}  ema={above_50ema:+d}  "
          f"pos={current_qty:>+6.0f}→{target_qty:>+6.0f}  "
          f"price=${price:>8.2f}  {order_side.value.upper()} {abs(order_qty):.0f} shares")

    # Place the order, passing regime context for bracket adjustment in AI mode.
    # If the order is accepted, immediately queue a background backtest for this
    # symbol so we can see whether the strategy is historically sound.
    order_placed = place_order(
        client, symbol, abs(order_qty), order_side,
        price_mode=price_mode,
        entry_price=algo_entry,
        stop_loss=algo_stop_loss,
        take_profit=algo_take_profit,
        regime=regime,
        adx_value=adx_value,
    )

    if order_placed:
        # Record the signal so duplicate orders are blocked on the next cycle
        with _executed_lock:
            _last_executed_signal[symbol] = final_signal
        # Backtest runs in a daemon thread — never delays the next scan cycle
        trade_backtester.run_after_trade(symbol, capital=amount_per_trade)


# =============================================================================
#  BACKGROUND THREAD: WATCHLIST REFRESH  (every 60 minutes)
# =============================================================================

def _watchlist_refresh_loop(client: TradingClient) -> None:
    """
    Background thread that calls get_watchlist() on startup and then
    every WATCHLIST_REFRESH_INTERVAL seconds.

    Before each refresh, all open positions are liquidated so we never
    hold stocks that are no longer on the active watchlist.
    """
    global _watchlist
    first_run = True
    while not _shutdown.is_set():
        # On the very first run there are no positions to clear yet.
        # On every subsequent refresh, liquidate before switching watchlists.
        if not first_run:
            print("\n[WATCHLIST] Watchlist refresh due — liquidating all positions first...")
            liquidate_all_positions(client)
        first_run = False

        print("\n[WATCHLIST] Fetching new watchlist from Gemini...")
        try:
            new_list = get_watchlist()
            with _watchlist_lock:
                _watchlist = new_list
            symbols = [s["symbol"] for s in new_list]
            print(f"[WATCHLIST] Active watchlist: {symbols}")
        except Exception as e:
            print(f"[WATCHLIST] Error fetching watchlist: {e}")

        # Wait for the next refresh (wakes up immediately if shutdown is set)
        _shutdown.wait(timeout=WATCHLIST_REFRESH_INTERVAL)


# =============================================================================
#  BACKGROUND THREAD: TRADING SCAN LOOP  (every 5 seconds)
# =============================================================================

def _trading_scan_loop(client: TradingClient, amount_per_trade: float, price_mode: str, use_simple: bool) -> None:
    """
    Background thread that scans all stocks on the current watchlist
    every SCAN_INTERVAL seconds and executes trades where warranted.
    """
    while not _shutdown.is_set():
        # ── Market hours check ────────────────────────────────────────
        # Ask Alpaca whether the market is currently open.
        # If closed, print once and sleep until the next open rather than
        # hammering the API every 15 seconds with pointless algorithm calls.
        try:
            clock = client.get_clock()
            if not clock.is_open:
                next_open = clock.next_open.strftime("%Y-%m-%d %H:%M %Z")
                print(f"\n[SCAN] Market is closed. Next open: {next_open}  — holding.")
                # Sleep until 60 seconds after the next open so the first
                # bar has time to form, then re-check.
                seconds_until_open = max(
                    0,
                    (clock.next_open - clock.timestamp).total_seconds() + 60,
                )
                _shutdown.wait(timeout=seconds_until_open)
                continue
        except Exception as e:
            print(f"[SCAN] Could not fetch market clock: {e} — skipping cycle.")
            _shutdown.wait(timeout=SCAN_INTERVAL)
            continue

        with _watchlist_lock:
            current_watchlist = list(_watchlist)   # snapshot to avoid lock during scan

        if not current_watchlist:
            print("[SCAN] Watchlist is empty — waiting for watchlist thread...")
            _shutdown.wait(timeout=SCAN_INTERVAL)
            continue

        scan_time   = datetime.now().strftime("%H:%M:%S")
        mode_label  = "AI price" if price_mode == "ai" else "market price"
        algo_label  = "complex+simple" if use_simple else "complex only"
        print(f"\n[SCAN] {scan_time}  budget=${amount_per_trade:,.2f}/trade  "
              f"price={mode_label}  algo={algo_label}")
        print("  " + "─" * 62)

        for stock in current_watchlist:
            try:
                decide_and_trade(client, stock, amount_per_trade, price_mode, use_simple)
            except Exception as e:
                print(f"  {stock['symbol']:<6}  ERROR   Unexpected: {e}")

        print("  " + "─" * 62)

        # Wait SCAN_INTERVAL seconds before the next cycle
        _shutdown.wait(timeout=SCAN_INTERVAL)


# =============================================================================
#  STATUS DISPLAY  (printed every cycle in the main thread)
# =============================================================================

def print_status(client: TradingClient) -> None:
    """Print a compact summary of current positions and last signals."""
    try:
        account   = client.get_account()
        positions = client.get_all_positions()

        print(f"\n{'═'*60}")
        print(f"  Account  |  Buying Power: ${float(account.buying_power):>12,.2f}"
              f"  |  Portfolio: ${float(account.portfolio_value):>12,.2f}")
        print(f"{'─'*60}")

        if positions:
            print(f"  {'SYMBOL':<6}  {'QTY':>8}  {'AVG ENTRY':>10}  "
                  f"{'MKT VALUE':>12}  {'UNREAL P/L':>12}")
            for p in positions:
                print(f"  {p.symbol:<6}  {float(p.qty):>+8.2f}  "
                      f"${float(p.avg_entry_price):>9,.4f}  "
                      f"${float(p.market_value):>11,.2f}  "
                      f"${float(p.unrealized_pl):>+11,.2f}")
        else:
            print("  (no open positions)")

        print(f"{'─'*60}")
        with _signals_lock:
            signals_snapshot = dict(_last_signals)

        if signals_snapshot:
            # Determine whether the simple algo column should be shown.
            # If every entry has simple=None (disabled), omit the column.
            show_simple = any(sig.get("simple") is not None for sig in signals_snapshot.values())
            smpl_hdr    = f"{'SMPL':<4}  " if show_simple else ""
            print(f"  {'SYM':<6}  {smpl_hdr}{'CMPLX':<5}  {'CONF':>5}  "
                  f"{'REGIME':<12}  {'ADX':>5}  {'SLOPE':>6}  {'EMA':>3}  {'VETO'}")
            for sym, sig in signals_snapshot.items():
                veto_str  = sig.get("veto") or "—"
                smpl_part = f"{sig['simple']:<4}  " if show_simple else ""
                print(f"  {sym:<6}  {smpl_part}{sig['complex']:<5}  "
                      f"{sig['confidence']:>4.0%}  "
                      f"{sig.get('regime','?'):<12}  "
                      f"{sig.get('adx', 0):>5.1f}  "
                      f"{sig.get('slope_pct', 0):>+5.2f}%  "
                      f"{sig.get('above_50ema', 0):>+3d}  "
                      f"{veto_str}")

        print(f"{'═'*60}\n")

    except Exception as e:
        print(f"[STATUS] Could not retrieve account data: {e}")


# =============================================================================
#  USER INPUT HELPERS
# =============================================================================

def get_amount_per_trade() -> float:
    """Ask the user for their dollar budget per trade and validate it."""
    while True:
        raw = input("Enter amount per trade in USD (e.g. 500): $").strip()
        try:
            amount = float(raw)
            if amount > 0:
                return amount
            print("[ERROR] Amount must be greater than zero.")
        except ValueError:
            print("[ERROR] Please enter a valid number (e.g. 500 or 1000.50).")


def get_price_mode() -> str:
    """
    Ask the user whether to use market orders or AI-decided limit orders.

    Returns
    -------
    "market" — plain market order, fills instantly at current price.
    "ai"     — limit order at the complex algorithm's entry_price, with
               automatic stop-loss and take-profit bracket legs.
               The order only fills if the market reaches the algo's price.
    """
    print("\nPrice mode:")
    print("  [1] Market  — fill immediately at the current market price")
    print("  [2] AI      — TraderAI sets the entry price, stop-loss, and")
    print("                take-profit automatically using the complex algorithm")
    while True:
        choice = input("Choose (1 or 2): ").strip()
        if choice == "1":
            print("[INFO] Price mode: Market orders.")
            return "market"
        elif choice == "2":
            print("[INFO] Price mode: AI-decided limit + bracket orders.")
            return "ai"
        else:
            print("[ERROR] Please enter 1 or 2.")


def get_use_simple_algo() -> bool:
    """
    Ask whether the simple algorithm should participate in trade decisions.

    When enabled (default):
        The simple algo acts as a second opinion. Depending on risk level it
        must either agree with the complex algo (to open MEDIUM/HIGH-risk
        positions, or to close LOW-risk ones) or is ignored.

    When disabled:
        The complex algorithm alone makes every decision for every stock,
        regardless of risk level. Faster signals, but no cross-check.
    """
    print("\nSimple algorithm:")
    print("  [1] Enabled  — acts as a second opinion (cross-checks the complex algo)")
    print("  [2] Disabled — complex algorithm decides alone for all stocks")
    while True:
        choice = input("Choose (1 or 2): ").strip()
        if choice == "1":
            print("[INFO] Simple algorithm: ENABLED.")
            return True
        elif choice == "2":
            print("[INFO] Simple algorithm: DISABLED — complex algo decides alone.")
            return False
        else:
            print("[ERROR] Please enter 1 or 2.")

def main() -> None:
    print("=" * 60)
    print("  TraderAI — Automated Stock Trading Bot")
    mode = "LIVE (REAL MONEY)" if LIVE_TRADING else "PAPER (simulated)"
    print(f"  Mode: {mode}")
    print("=" * 60)

    # ── Safety confirmation for live trading ──────────────────────────
    if LIVE_TRADING:
        print("\n[WARNING] LIVE_TRADING is True — this uses REAL MONEY.")
        confirm = input("   Type 'yes' to continue, anything else to abort: ").strip().lower()
        if confirm != "yes":
            print("[INFO] Aborted.")
            return

    # ── Load API keys ─────────────────────────────────────────────────
    api_key, secret_key = load_api_keys()

    # ── Connect to Alpaca ─────────────────────────────────────────────
    try:
        client = create_client(api_key, secret_key)
        acct = client.get_account()
        print(f"[INFO] Connected. Buying power: ${float(acct.buying_power):,.2f}\n")
    except Exception as e:
        print(f"[ERROR] Could not connect to Alpaca: {e}")
        return

    # Pass the same credentials to the backtester so it can fetch
    # historical bars from Alpaca using the same account and feed.
    trade_backtester.configure(api_key=api_key, secret_key=secret_key, feed="sip")

    # ── Ask user for trade budget, price mode, and algo preference ───────
    amount_per_trade = get_amount_per_trade()
    price_mode       = get_price_mode()
    use_simple       = get_use_simple_algo()
    print(f"\n[INFO] Budget: ${amount_per_trade:,.2f}/trade  |  "
          f"Price: {'AI limit orders' if price_mode == 'ai' else 'Market orders'}  |  "
          f"Algo: {'Complex + Simple' if use_simple else 'Complex only'}\n")

    # ── Start the watchlist refresh thread ────────────────────────────
    # The client is passed in so the thread can liquidate positions before
    # each refresh.
    watchlist_thread = threading.Thread(
        target=_watchlist_refresh_loop,
        args=(client,),
        name="WatchlistRefresh",
        daemon=True   # dies automatically when main thread exits
    )
    watchlist_thread.start()

    # Wait for the watchlist thread to get its first response from Gemini.
    # Gemini can take 30–120 seconds, so we poll every 5 s and wait up to 3 minutes.
    print("[INFO] Waiting for Gemini to return the initial watchlist "
          "(this can take up to a few minutes)...")
    wait_limit   = 180   # seconds before we give up and warn
    wait_elapsed = 0
    while wait_elapsed < wait_limit:
        time.sleep(5)
        wait_elapsed += 5
        with _watchlist_lock:
            ready = bool(_watchlist)
        if ready:
            break
        print(f"[INFO] Still waiting for Gemini... ({wait_elapsed}s elapsed)")
    else:
        print("[WARNING] Gemini did not respond within 3 minutes. "
              "The scan thread will start anyway and retry on the next watchlist cycle.")

    # ── Start the trading scan thread ────────────────────────────────
    scan_thread = threading.Thread(
        target=_trading_scan_loop,
        args=(client, amount_per_trade, price_mode, use_simple),
        name="TradingScan",
        daemon=True
    )
    scan_thread.start()

    # ── Main thread: print status + handle Ctrl-C ────────────────────
    print("[INFO] TraderAI is running. Press Ctrl+C to stop.\n")
    try:
        while True:
            time.sleep(30)          # print a status summary every 30 seconds
            print_status(client)
    except KeyboardInterrupt:
        print("\n[INFO] Shutdown requested — liquidating all positions...")
        liquidate_all_positions(client)
        print("[INFO] Stopping all threads...")
        _shutdown.set()
        watchlist_thread.join(timeout=5)
        scan_thread.join(timeout=5)
        print("[INFO] TraderAI stopped. Goodbye.")
        sys.exit(0)


if __name__ == "__main__":
    main()